package com.demo.test;

public class HappySum {

	
	 static long interestingSum(int N, int[] A){
	       // Write your code here
	        long result = 0,tmpSum=0;
	        int flag=1;
	        if(N == 1)result=A[0];
	        for(int i=0;i<A.length;i++){
	            tmpSum=A[i];
	            flag=i+2;
	            for(int j=i+1;j<A.length;j++){
	            	System.out.println("j ="+j+"  flag="+flag);
	                if(j==flag) {
	                	tmpSum+=A[j];
	                	flag+=2;
	                }
	                else
	                tmpSum-=A[j];
	                if(tmpSum>result)result=tmpSum;
	            }
	            flag=0;   
	        }
	        
	        if(A[N-1]>result)result=A[N-1];
	        return result;
	    
	    }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(interestingSum(4, new int[] {-4,-10,3,5}));
		
	}
	

}
