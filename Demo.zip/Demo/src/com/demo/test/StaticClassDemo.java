package com.demo.test;

class  InnerStaticClassDemo{

	private String s="demo main class";
	public static class firstStaticClass{
		
		private String str="Demo inner static class";
		public void display() {
			System.out.println("Inner static demo class "+str);
		}
		
	}
	
	public class InnerClass{
		public void display() {
			System.out.println("Inner demo class using private var of demo "+s);
		}
	}
}

public class StaticClassDemo{
	
	public static void main(String[] args) {
		
	//here we didn't created object of Outer class directly created inner static class object
	//and used it
	InnerStaticClassDemo.firstStaticClass fs=new InnerStaticClassDemo.firstStaticClass();
	fs.display();
	
	//This statement gives error coz outer class object is not created
	// and inner class is not a static class
	InnerStaticClassDemo.InnerClass in=new InnerStaticClassDemo.InnerClass();
	
	//To solve above problem
	InnerStaticClassDemo sd=new InnerStaticClassDemo();
	
	InnerStaticClassDemo.InnerClass in2 =sd.new InnerClass();
	
	}
}