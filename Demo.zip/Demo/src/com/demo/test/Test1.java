package com.demo.test;

import java.util.Arrays;
import java.util.Random;

class teach{
	String name ="adi";
}
class stud extends teach{
	String name="don";
}
public class Test1 {

	int k=10;
	public static int getFact(int i) {
		if(i==0||i==1)return 1;
	
		return i*getFact(i-1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test1 t=new Test1();
		int[] i=new int[] {1,4,3,6,2};
		
		System.out.println(getFact(4));
		Random r=new Random();
		System.out.println(r.nextInt(15));
		System.out.println("Value of k is"+t.k);
		
		teach t1=new stud();
		System.out.println(t1.name);
		
		String s="";
		s+='c'+2;
		System.out.println(s);
		
		System.out.println(Math.pow(3, 5));
		
		boolean sh=true;
		sh=!sh;
		System.out.println(sh);
		System.out.println(!sh);
		int n=19273;
		
	}

	

}
