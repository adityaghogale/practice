package com.demo.test;

public class AllSubstrings {

	public static void printSubstring(String s) {
		for(int i=0;i<s.length();i++) {
			String ss="";
			for(int j=i;j<s.length();j++) {
				ss+=s.charAt(j);
				System.out.println(ss);
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abcd";
		
		printSubstring(s);
	}

}
