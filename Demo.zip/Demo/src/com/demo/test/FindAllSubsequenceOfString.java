package com.demo.test;

import java.util.ArrayList;
import java.util.List;

public class FindAllSubsequenceOfString {

	public static List<String> ls=new ArrayList<>();
	
	public static void findAllSubsequenceString(String s,String ans) {
		if (s.length() == 0) {
            ls.add(ans);
            return;
        }
 
        // We add adding 1st character in string
		findAllSubsequenceString(s.substring(1), ans + s.charAt(0));
 
        // Not adding first character of the string
        // because the concept of subsequence either
        // character will present or not
		findAllSubsequenceString(s.substring(1), ans);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "abcd";
		findAllSubsequenceString(s, ""); // Calling a function
        System.out.println(ls);
	}

}
