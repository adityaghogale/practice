package com.demo.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class isPowerOfNumber {
	public static boolean isPowerOfTwo(int n) {
		
		if (n == 0)
            return false;
 
        return (int)(Math.ceil((Math.log(n) / Math.log(2))))
            == (int)(Math.floor(
                ((Math.log(n) / Math.log(2)))));
	}
	
	public static boolean isPowerOf2(int n) {
		if(n==1)return true;
		if(n%2 !=0 || n==0)return false;
		return isPowerOf2(n/2);
	}
	
	public static String addStrings(String num1, String num2) {
        if(num1.length() > num2.length()) {
        	String tmp=num1;
        	num1=num2;
        	num2=tmp;
        }
        num1=new StringBuilder(num1).reverse().toString();
        num2=new StringBuilder(num2).reverse().toString();
        String st="";
        int carry=0;
        for(int i=0;i<num1.length();i++) {
        	int sum=(int) (num1.charAt(i)-'0')+(int)(num2.charAt(i)-'0')+carry;
        	carry=0;
        	if(sum>9) {
        		st+=(sum%10);
        		carry=sum/10;
        	}
        	else
        		st+=sum;
        		
        }
        for(int i=num1.length();i<num2.length();i++) {
        	
        	if(carry!=0) {
        		int sum=(num2.charAt(i)-'0')+carry;
        		carry=0;
        		if(sum>9) {
            		st+=(sum%10);
            		carry=sum/10;
            	}
            	else
            		st+=sum;
        	}
        	else {
        		st+=num2.charAt(i);
        	}
        }
        if(carry !=0)st+=carry;
        st=new StringBuilder(st).reverse().toString();
        return st;
        }
	
	public static String addStrings2(String num1, String num2) {
		
		int i=num1.length()-1;
		int j=num2.length()-1;
		int carry=0;
		String s="";
		while(i>=0 || j>=0) {
			int n1=0;
			int n2=0;
			if(i>=0)
				n1=num1.charAt(i--)-'0';
			if(j>=0)
				n2=num2.charAt(j--)-'0';
			
			int sum=(n1+n2+carry);
			carry=0;
			if(sum>=10) {
				s+=sum%10;
				carry=sum/10;
			}
			else
			s+=sum;
			
		}
		if(carry !=0)s+=carry;
		return new StringBuilder(s).reverse().toString();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(isPowerOf2(1073741825));
		System.out.println(13%10);
		System.out.println(addStrings2("1","9"));
		System.out.println(addStrings2("456","77"));
	}

}
