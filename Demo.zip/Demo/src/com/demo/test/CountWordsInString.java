package com.demo.test;

import java.util.Arrays;
import java.util.HashSet;

public class CountWordsInString {

	public static String[] countWords(String s) {
		return s.split("\\s");
	}
	
	public int countOccuranceOfWords(String[] words,String s) {
		int count=0;
		HashSet<String> hs=new HashSet<>();
		for(String ss:words){
			hs.add(ss);
		}
		String[]str=countWords(s);
		for(String ss:str) {
			if(hs.contains(ss))count++;
		}
		return count;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Luffy is the joyboy and the pirateking";
		CountWordsInString cs=new CountWordsInString();
		String[] sr= {"Luffy","the"};
		System.out.println(cs.countOccuranceOfWords(sr, s));
	}

}
