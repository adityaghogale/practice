package com.demo.test;

public class Player {

	int score;
	String name;
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Player(int score, String name) {
		super();
		this.score = score;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Player [score=" + score + ", name=" + name + "]";
	}

	
}
