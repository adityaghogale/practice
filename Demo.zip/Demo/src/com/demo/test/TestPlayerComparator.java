package com.demo.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestPlayerComparator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Player[] pList=new Player[]{new Player(95,"Adi"),new Player(80,"Luffy"),new Player(91,"Zoro"),
				new Player(95,"Aaa")};
		SortName sr=new SortName();
		Arrays.sort(pList, sr);
		System.out.println(Arrays.toString(pList));
	}

}
