package com.demo.test;

class A{
	
	A(){
		System.out.println("From A const.");
	}
	public void xys() {
		System.out.println("From A");
	}
}
class B extends AAA{

	B(){
		System.out.println("From B const.");
	}
	public void getOwnerName() {
		System.out.println("Owner is Raju");
	}
	public void xys() {
		System.out.println("From B");
	}

}

public class RunIt{
	public static void main(String args[]) {
		
		AAA a=new B();
		a.xys();
		B b=new B();
		b.getOwnerName();
		B b2=(B)new AAA();
		b2.xys();
	}
}

