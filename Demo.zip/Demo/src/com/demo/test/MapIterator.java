package com.demo.test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class MapIterator {

	public static void reverseString(char[] s) {
        int i=0,j=s.length-1;
        while(i<j){
            char tmp=s[i];
            s[i++]=s[j];
            s[j--]=tmp;
        }
        System.out.println(Arrays.toString(s));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer,String> map=new HashMap<>();
		
		map.put(1, "Adi");
		map.put(2, "Luffy");
		map.put(3, "Zoro");
		map.put(4, "Sanji");
		map.entrySet().forEach((x)->{System.out.println(x.getKey());});
		reverseString("Aditya".toCharArray());
		
	}
	static String re() throws FileNotFoundException, IOException {
		String path="C:\\Users\\aghogale\\OneDrive - Capgemini\\Desktop\\Objective&Info.txt";
		try (FileReader fr = new FileReader(path);
		         BufferedReader br = new BufferedReader(fr)) {
			
			return br.readLine();
		}
	}
}
