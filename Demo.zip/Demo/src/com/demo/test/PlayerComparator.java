package com.demo.test;

import java.util.Comparator;

public class PlayerComparator {

}

class SortName implements Comparator<Player>{
	@Override
	public int compare(Player p1,Player p2) {
		int tmpScore =p2.score-p1.score;
		if(tmpScore == 0) {
			System.out.println("For "+p2.name+" &"+p1.name+" score: "+(p2.name).compareTo(p1.name));
			return p2.name.compareTo(p1.name);
		}
		else
		return tmpScore;
	}
}