package com.demo.trickque;

import java.util.Arrays;

/**
 * two-elements-whose-sum-is-closest-to-zero
 * 
 * @author aghogale
 */

/*Algo
 	Sort all the elements of the input array. 
	Use two index variables l and r to traverse from left and right ends respectively. Initialize l as 0 and r as n-1. 
	sum = a[l] + a[r] 
	If sum is -ve, then l++ 
	If sum is +ve, then r� 
	Keep track of abs min sum. 
	Repeat steps 3, 4, 5 and 6 while l < r
 */

public class SumOfTwoElementClosestToZero {
	
	public static void closestSum(int[] ar) {
		
		Arrays.sort(ar);
		int i=0,j=ar.length-1,sum,minSum=Integer.MAX_VALUE;
		int l_min=0,r_min=0;
		while(j>i) {
			sum=ar[i]+ar[j];
			
			if(Math.abs(sum)<Math.abs(minSum)) {
				minSum=sum;
				l_min=ar[i];
				r_min=ar[j];
			}
			if(sum>0)j--;
			if(sum<0)i++;
		}
		System.out.println("Two elements are "+l_min+" "+r_min);
	}
	
	public static void main(String[] args) {
		closestSum(new int[] {1, 60, -10, 70, -80, 85});
	}
}
