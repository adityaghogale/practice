package com.demo.trickque;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommonCharBetweenStrings {

	public static char[] getCommonCharacters(String s) {
		char[] ch=new char[s.length()/2];
		int j=0;
		String[] str=s.split(" ");
		for(char c:str[0].toCharArray()) {
			boolean flag=true;
			for(int i=1;i<str.length;i++) {
				if (!(str[i].indexOf(c) > 0)) {
					flag=false;
					break;
				}
			}
			if(flag)
				ch[j++]=c;
		}
		
		return ch;
	}
	
	public static void getCommonCharacters2(String s) {
	
		Map<Character,Integer> mp=new HashMap<>();
		String[] str=s.split(" ");
		for(char c:s.toCharArray())
			mp.put(c, mp.getOrDefault(c,0)+1);
		
		for(Map.Entry<Character,Integer> m:mp.entrySet()) {
			if(m.getValue() == str.length)
				System.out.println(m.getKey());
		}
	}
	
	public static void main(String[] args) {
		String s="we are the champe";
		System.out.println(Arrays.toString(getCommonCharacters(s)));
		getCommonCharacters2(s);
	}
}
