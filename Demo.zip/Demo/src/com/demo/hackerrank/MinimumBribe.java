package com.demo.hackerrank;

import java.util.Arrays;
import java.util.List;

public class MinimumBribe {

	public static void minimumBribes(List<Integer> q) {
	    // Write your code here
	        int count=0;
	        boolean flag=false;
	        for(int i=1;i<q.size()-2;i++){
	            if(q.get(i) >q.get(i+3)){
	                flag=true;
	                break;
	                
	            }
	            count+=q.get(i)==q.get(i+1)?1:q.get(i)==q.get(i+2)?2:0;
	        }
	        if(flag)System.out.println("Too chaotic");
	        else
	        System.out.println(count);
	    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		minimumBribes(Arrays.asList(2, 1, 5, 3, 4));
	}

}
