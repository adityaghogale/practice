package com.demo.hackerrank;

import java.math.BigInteger;

public class ExtraLongFactorial {

	public static void main(String[] args) {
		BigInteger b = BigInteger.ONE;
		int n=15;
		while(n!=0) {
			b=b.multiply(BigInteger.valueOf(n));
			n--;
		}
		System.out.println(b);
		
		System.out.println(appendAndDelete("hackerhappy", "hackerrank", 9));
	}
	 public static String appendAndDelete(String s, String t, int k) {
		    // Write your code here
		        if(s.equals(t)) return "Yes";
		        int countS=0;
		        int i=0,j=0;
		        while(i<s.length() && j<t.length()){
		            if(!(s.charAt(i) ==t.charAt(j))) {
		            	if(!((s.length()-i)*2 <= k))return "No";
		            }
		            i++;j++;
		        }
		        if((s.length()-i)*2 <= k)return "Yes";
		        return "No"; 
		}
	 
}


