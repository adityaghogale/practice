package com.demo.hackerrank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArraysLeftRotation {

	public static List<Integer> rotLeft(List<Integer> a, int d) {
	    // Write your code here
		List<Integer> ls=new ArrayList<>();
        for(int i=d;i<a.size();i++){
            ls.add(a.get(i));
        }
        for(int i=0;i<d;i++)
        ls.add(a.get(i));
        return ls;
	    }

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(rotLeft(Arrays.asList(1,2,3,4,5),2));
	}

}
