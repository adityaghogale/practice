package com.demo.threadque;


//We can directly use the Thread class to spawn new threads using the constructors defined above.
public class DirectThreadCreation {

	public static void main(String args[]) {
		
		// creating an object of the Thread class using the constructor Thread(String name)   
		Thread t1=new Thread("Thread1");
		t1.start();
		System.out.println(t1.getName());
	}
}
