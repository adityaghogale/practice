package com.demo.threadque;

//using runnable interface
/*
If you are not extending the Thread class,
your class object would not be treated as a thread object. 
So you need to explicitly create the Thread class object. 
We are passing the object of your
class that implements Runnable so that your class run() method may execute.*/


public class UsingRunnableIntf implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Thread is running...");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		UsingRunnableIntf u1=new UsingRunnableIntf();
		Thread t1=new Thread(u1); // Using the constructor Thread(Runnable r)  
		t1.start();
		System.out.println(t1.getName());
	}

}
