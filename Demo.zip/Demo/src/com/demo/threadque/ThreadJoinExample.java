package com.demo.threadque;

public class ThreadJoinExample extends Thread {
	
	public ThreadJoinExample(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}
	public ThreadJoinExample() {
		// TODO Auto-generated constructor stub
		super();
	}
	@Override
	public void run() {
		for(int i=0;i<3;i++) {
			System.out.println(i);
			try {
				System.out.println("Current Thread is "+Thread.currentThread().getName());
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadJoinExample t1=new ThreadJoinExample();
		ThreadJoinExample t2=new ThreadJoinExample("Shyam");
		t1.start();
		try {
			t1.setName("Raju");
			t1.join(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Hello from main");
		
	}

}
