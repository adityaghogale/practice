package com.demo.threadque;

public class DaemonThreadExample extends Thread {

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(Thread.currentThread().isDaemon())System.out.println("In Daemon thread");
		else
			System.out.println("In user thread");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaemonThreadExample d1=new DaemonThreadExample();
		DaemonThreadExample d2=new DaemonThreadExample();
		d1.start();
		//Note: If you want to make a user thread as Daemon,
		//it must not be started otherwise it will throw IllegalThreadStateException.
		
		d2.setDaemon(true);
		d2.start();
	}

}
