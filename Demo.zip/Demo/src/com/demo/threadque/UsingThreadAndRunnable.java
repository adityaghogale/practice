package com.demo.threadque;


//Using the Thread Class: Thread(Runnable r, String name)

public class UsingThreadAndRunnable implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

		System.out.println("Thread is running...");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable r1=new UsingThreadAndRunnable();
		Thread t1=new Thread(r1,"MyFirstThread");
		t1.start();
		System.out.println(t1.getName());
	}

}
