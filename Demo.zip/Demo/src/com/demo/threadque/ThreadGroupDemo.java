package com.demo.threadque;

public class ThreadGroupDemo extends Thread {

	
	@Override
	public void run() {
		for(int i=0;i<5;i++) {
			try {
				
				System.out.println(i);
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadGroup tg1=new ThreadGroup("Group A");
		Thread t1=new Thread(tg1,"1");
		Thread t2=new Thread(tg1,"2");
		Thread t3=new Thread(tg1,"3");
		t1.start();
		t2.start();
		t3.start();
		System.out.println(tg1.activeCount());
	}

}
