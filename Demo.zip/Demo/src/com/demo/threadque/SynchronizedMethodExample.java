package com.demo.threadque;


class PrintHello {

	// non-synchronized method
	public void printName(String s) {
		for (int i = 0; i < 3; i++) {
			try {
				System.out.println("Hello from non-synchronized method" + s);
				Thread.sleep(2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// synchronized method
	synchronized public void printNameSync(String s) {
		for (int i = 0; i < 3; i++) {
			try {
				System.out.println("Hello from synchronized method" + s);
				Thread.sleep(2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

public class SynchronizedMethodExample {

	public static void main(String args[]) {
		final PrintHello ph = new PrintHello();

		Thread t = new Thread() {
			public void run() {
				ph.printName(Thread.currentThread().getName());
			
				ph.printNameSync(Thread.currentThread().getName());
			}
		};

		Thread t2 = new Thread() {
			public void run() {
				ph.printName(Thread.currentThread().getName());
			
				ph.printNameSync(Thread.currentThread().getName());
			}
		};

		t.start();
		t2.start();
	}
}
