package com.demo.threadque;


// using thread class as parent class

public class UsingThreadAsParentClass extends Thread {
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(i);
			try {
				Thread.sleep(1);
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UsingThreadAsParentClass f1=new UsingThreadAsParentClass();
		UsingThreadAsParentClass f2=new UsingThreadAsParentClass();
		f1.start();
		f2.start();
		f1.start();
		
		//sleep implementation in main thread
		try {
			Thread.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Hello form main");
	}

}
