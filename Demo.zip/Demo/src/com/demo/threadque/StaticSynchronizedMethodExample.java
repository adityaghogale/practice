package com.demo.threadque;


class Table{
	public static synchronized void printVal(int num) {
		for(int i=1;i<5;i++) {
			System.out.println(i*num);
			try{
				Thread.sleep(2);
			}catch(InterruptedException e) {
				System.out.println(e);
			}
		}
	}
	
	//this is same as above
	public static void printHello(int num){
		synchronized (Table.class) {
		for(int i=1;i<5;i++) {
			System.out.println(i*num);
			try{
				Thread.sleep(2);
			}catch(InterruptedException e) {
				System.out.println(e);
			}
		}
		}
	}
}
public class StaticSynchronizedMethodExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t1=new Thread() {
			public void run() {
				Table.printVal(1);
			}
		};
		
		Thread t2=new Thread() {
			public void run() {
				Table.printVal(10);
			}
		};
		
		Thread t3=new Thread() {
			public void run() {
				Table.printVal(100);
			}
		};
		
		t1.start();
		t2.start();
		t3.start();
	}

}
