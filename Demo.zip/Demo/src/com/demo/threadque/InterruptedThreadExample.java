package com.demo.threadque;

 class demo{
	 
	 public static synchronized void printNum(int num) {
		 for(int i=1;i<4;i++) {
			 try {
				 Thread.sleep(2);
				 System.out.println(i*num);
				 
			 }
			 catch(InterruptedException e) {
				 System.out.println(e+" handled");
			 }
			 System.out.println("Thread is running...");
			 System.out.println(Thread.currentThread().isInterrupted());
		 }
	 }
 }

public class InterruptedThreadExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thread t1=new Thread() {
			public void run() {
				demo.printNum(1);
			}
		};
		Thread t2=new Thread() {
			public void run() {
				demo.printNum(10);
			}
		};
		t1.start();
		t2.start();
		t1.interrupt();
		System.out.println(t1.isInterrupted());
		System.out.println(t1.interrupted());
	}

}
