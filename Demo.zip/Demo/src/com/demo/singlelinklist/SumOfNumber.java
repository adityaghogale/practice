package com.demo.singlelinklist;

public class SumOfNumber {

	
	static ListNode sumOfNum(ListNode l1,ListNode l2) {
		ListNode l=new ListNode();
		ListNode a1F=l;
		int carry=0;
		while(l1!=null || l2!=null || carry !=0) {
			if(l1!=null) {
				carry+=l1.val;
				l1=l1.next;
			}
			if(l2!=null) {
				carry+=l2.val;
				l2=l2.next;
			}
				l.next=new ListNode(carry%10);
				carry=carry/10;
				l=l.next;
			
		}
		return a1F.next;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListNode l1=new ListNode(5);
		ListNode l1F=new ListNode();
		l1F=l1;
		l1.next=new ListNode(6);
		l1=l1.next;
		l1.next=new ListNode(4);
		l1=l1.next;
		l1.next=new ListNode(1);
		l1=l1.next;
		l1.next=new ListNode(5);
		l1=l1.next;
		
		
		ListNode l2=new ListNode(2);
		ListNode l2F=new ListNode();
		l2F=l2;
		l2.next=new ListNode(4);
		l2=l2.next;
		l2.next=new ListNode(3);
		l2=l2.next;
		
		ListNode ans=sumOfNum(l1F,l2F);
		while(ans.next != null) {
			System.out.println(ans.val);
			ans=ans.next;
		}
		


	}

}
