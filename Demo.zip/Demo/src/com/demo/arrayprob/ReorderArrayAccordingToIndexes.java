package com.demo.arrayprob;

import java.util.Arrays;

public class ReorderArrayAccordingToIndexes {

	public static void reorderArray(int[] ar,int[] index) {
		
		for(int i=0;i<index.length;i++) {
			
			int temp=ar[i];
			ar[i]=ar[index[i]];
			ar[index[i]]=temp;
		}
		
		System.out.println(Arrays.toString(ar));
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		reorderArray(new int[] {10, 11, 12}, new int[]{1, 0, 2});
	}

}
