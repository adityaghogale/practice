package com.demo.arrayprob;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Two_DIntegerArrayTo1D {

	static Integer[] flattenArray(Object[] input) {
		List<Integer> ls=new ArrayList<>();
		for(Object o:input) {
			if(o instanceof Integer ) {
				ls.add((Integer) o);
			}
			else if(o instanceof Object[]) {
				ls.addAll(Arrays.asList(flattenArray((Object[]) o)));
			}
			
		}
		return ls.toArray(new Integer[ls.size()]);
	}
	
	static Object[] getFlat(Object o) {
		List<Object> ls=new ArrayList<>();
	
			for(int i=0;i<Array.getLength(o);i++) {
				Object o1=getFlat(Array.get(o,i));
				if(o1.getClass().isArray()) {
					ls.addAll(Arrays.asList(o1));
			}
		else {
			ls.add(o);
			System.out.println(o);
		}
			}
			
		return ls.toArray();
		
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer[][] n=new Integer[][] {{1,2,3},{4,5},{6}};
		
		System.out.println(Arrays.toString(flattenArray(n)));
		System.out.println(Arrays.toString(getFlat(n)));

	}

}
