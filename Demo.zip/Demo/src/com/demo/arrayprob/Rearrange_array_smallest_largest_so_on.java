package com.demo.arrayprob;

import java.util.Arrays;

//Given an array of integers, the task is to print the array in the order � 
//smallest number, the Largest number,
//2nd smallest number, 2nd largest number, 3rd smallest number,
//3rd largest number, and so on�..

/*
Input : arr[] = [5, 8, 1, 4, 2, 9, 3, 7, 6]
Output :arr[] = {1, 9, 2, 8, 3, 7, 4, 6, 5}
*/


public class Rearrange_array_smallest_largest_so_on {

	public static void getRearrangeArray(int[] arr) {
		
		int n=arr.length;
		for(int i=0;i<n-1;i++) {
			for(int j=0;j<n-i-1;j++) {
				if(arr[j]>arr[j+1]) {
					
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
					
			}
		}
		int i=0,j=n-1;
		while(i<j) {
			System.out.print(arr[i++]+" ");
			System.out.print(arr[j--]+" ");
		}
		
	}
	
	public static void swap(int a,int b) {
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		getRearrangeArray(new int[] {1,3,5,2,8,4});
	}

}
