package com.demo.arrayprob;

import java.util.Arrays;

//Product array except itself
//{1,2,3,4} -> {24,12,8,6} 

public class ProductOfElementOfArrayExceptItself {

	static int[] getProductArray(int[] arr) {
		int product=1;
		int[] ans=new int[arr.length];
		for(int a:arr) {
			if(a==0) {
				continue;
			}
			product=product*a;
		}
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==0) {
				continue;
			}
			ans[i]=product/arr[i];
		}
		return ans;
	}
	

	//
	static int[] getProductArray2(int[] arr) {
		int len=arr.length;
		int left[]=new int[len];
		left[0]=1;
		
		int right[]=new int[len];
		right[len-1]=1;
		
		int ans[]=new int[len];
		
		//populate left array
		int product=1;
		for(int i=1;i<len;i++) {
			left[i]=arr[i-1]*left[i-1];
		}
		
		//populate right array
				int j=len-2;
				product=1;
				for(;j>=0;j--) {
					right[j]= right[j+1]*arr[j+1];
				}
				
			//populate ans array
				int i=0;
				j=len-1;
				
				for(int k=0;k<len;k++) {
					ans[k]=left[i]*right[i++];
				}
		return ans;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,2,3,4,0,-2};
		System.out.println(Arrays.toString(getProductArray(arr)));
		System.out.println(Arrays.toString(getProductArray2(arr)));
	}

}
