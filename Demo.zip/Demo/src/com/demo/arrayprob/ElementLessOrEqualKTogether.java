package com.demo.arrayprob;

public class ElementLessOrEqualKTogether {

	
	//my solution
	public static void getTogether(int[] arr,int k) {
		
		int count=0,tmpPos=0;
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<=k) {
				if(!(tmpPos+1<i)) {
					tmpPos=i;
					continue;
				}
				count++;
				tmpPos=i;
			}
		}
		System.out.println(count);
		
	}
	
	//geeksforgeeks
	static void minSwap(int arr[], int n, int k)
    {
 
        // Initially snowBallsize is 0
        int snowBallSize = 0;
 
        for (int i = 0; i < n; i++) {
 
            // Calculating the size of window required
            if (arr[i] <= k) {
                snowBallSize++;
            }
        }
 
        int swap = 0, ans_swaps = Integer.MAX_VALUE;
 
        for (int i = 0; i < snowBallSize; i++) {
            if (arr[i] > k)
                swap++;
        }
 
        ans_swaps = Math.min(ans_swaps, swap);
 
        for (int i = snowBallSize; i < n; i++) {
 
            // Checking in every window no. of swaps
            // required and storing its minimum
            if (arr[i - snowBallSize] <= k && arr[i] > k)
                swap++;
            else if (arr[i - snowBallSize] > k
                     && arr[i] <= k)
                swap--;
            ans_swaps = Math.min(ans_swaps, swap);
        }
        System.out.println(ans_swaps);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		getTogether(new int[] {2, 7,1,9, 5, 8, 7, 4,3,1}, 5);
		minSwap(new int[] {2, 7,1, 9, 5, 8, 7, 4,3,1},7, 5);
	}

}
