package com.demo.arrayprob;

import java.util.Arrays;

public class EvenPositionedGreaterThanOdd {

	public static void arrangeArray(int[] arr) {
	
		for(int i=1;i<arr.length;i++) {
			if((i-1)%2 == 0) {
				if(arr[i]>=arr[i-1]) 
				continue;
				else {
					int temp=arr[i];
					arr[i]=arr[i-1];
					arr[i-1]=temp;
				}
			}
			else {
				if(arr[i]<=arr[i-1]) 
					continue;
					else {
						int temp=arr[i];
						arr[i]=arr[i-1];
						arr[i-1]=temp;
					}
			}
			
		}
		
		System.out.println(Arrays.toString(arr));
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arrangeArray(new int[]{1, 3, 2, 2, 5});
	}

}
