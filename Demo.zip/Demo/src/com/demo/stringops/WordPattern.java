package com.demo.stringops;

import java.util.HashMap;
import java.util.Map;

public class WordPattern {

	public static boolean wordPattern(String pattern, String s) {
		  Map<String,Character> mp=new HashMap<>();
	        String[] ss=s.split(" ");
	        if(pattern.length()!=ss.length) return false;
	        for(int i=0;i<pattern.length();i++) {
	        	String str=ss[i];
	        	if(mp.containsKey(str)) {
	        		if(!(mp.get(str) == pattern.charAt(i)))
	        			return false;
	        	}
	        	else {
	        		if(mp.containsValue(pattern.charAt(i)))
	        			return false;
	        		mp.put(str, pattern.charAt(i));
	        	}
	        }
	        return true;
    }
	
	public static String multiply(String num1, String num2) {
        int n1=0,n2=0;
        for(int i=0;i<num1.length();i++){
            n1=(num1.charAt(i)-'0')+n1*10;
        }
        for(int i=0;i<num2.length();i++){
            n2=(num2.charAt(i)-'0')+n2*10;
        }
        System.out.println("n1="+n1+" n2="+n2);

        return n1*n2+"";
    }
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(wordPattern("abba","dog cat cat dog"));
		
		System.out.println(multiply("321","123"));
		
	}

}
