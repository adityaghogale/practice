package com.demo.stringops;

/*
We define the usage of capitals in a word to be right when one of the following cases holds:

All letters in this word are capitals, like "USA".
All letters in this word are not capitals, like "leetcode".
Only the first letter in this word is capital, like "Google".
Given a string word, return true if the usage of capitals in it is right.

 Input: word = "USA"
Output: true

Input: word = "FlaG"
Output: false
 
 */


public class DetectCapital {

	 public static boolean detectCapitalUse(String word) {
	        int minVal,maxVal,i=0;
	        if(word.length() <= 1)return true;
	        if(Character.isLowerCase(word.charAt(0))) {
	        	minVal=97;maxVal=122;
	        	i=1;
	        }
	        else if(Character.isLowerCase(word.charAt(1))){
	        	minVal=97;maxVal=122;
	        	i=2;
	        	}
	        else {
		        	minVal=65;maxVal=90;
	        }
	        for(;i<word.length();i++) {
	        	if(word.charAt(i)>=minVal && word.charAt(i)<=maxVal)
	        		continue;
	        	else 
	        		return false;
	        }
	        return true;

	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(DetectCapital.detectCapitalUse("Amazon"));
	}

}
