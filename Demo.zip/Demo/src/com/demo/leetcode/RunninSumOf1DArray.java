package com.demo.leetcode;

import java.util.Arrays;

public class RunninSumOf1DArray {

	//stupid method o(n^2)
	public static int[] runningSum(int[] nums) {
		int tmpSum=0;
		int[] tmp=new int[nums.length];
		for(int i=1;i<nums.length;i++) {
			for(int j=0;j<=i;j++)
				tmp[i]+=nums[j];
			tmpSum=0;
		}
		return tmp;
	}
	
	//quick method O(n)
	public static int[] runningSum2(int[] nums) {
		
		int i=1;
		while(i<nums.length) {
			nums[i]+=nums[i-1];
			i++;
		}
		return nums;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Arrays.toString(runningSum2(new int[] {1,2,3,4})));
	}

}
