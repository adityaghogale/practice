package com.demo.leetcode;

import java.util.Arrays;

/*Given a non-empty array of integers nums, 
 * every element appears twice except for one. Find that single one.
 */

public class SingleNumber {

	public static int singleNumber(int[] nums) {
        
		int num=0;
		Arrays.sort(nums);
		int i=0,j=nums.length-1;
		while(i<=j) {
			if(nums[i] != nums[i+1])
				return nums[i];
			else i+=2;
			if(nums[j] != nums[j-1])
				return nums[j];
			else j-=2;
						
		}
		return num;	
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(singleNumber(new int[] {-336,513,-560,-481,-174,101,-997,40,-527,-784,-283,-336,513,-560,-481,-174,101,-997,40,-527,-784,-283,354}));
	}

}
