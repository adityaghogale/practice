package com.demo.leetcode;

import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Queue;

/*
 [MEDIUM]
 
 You are given a 0-indexed integer array piles, where piles[i] represents the number of 
 stones in the ith pile, and an integer k. 
 You should apply the following operation exactly k times:\
Choose any piles[i] and remove floor(piles[i] / 2) stones from it.
Notice that you can apply the operation on the same pile more than once.
Return the minimum possible total number of stones remaining after applying the k operations.
floor(x) is the greatest integer that is smaller than or equal to x (i.e., rounds x down).
 
 
 Input: piles = [5,4,9], k = 2
Output: 12
Explanation: Steps of a possible scenario are:
- Apply the operation on pile 2. The resulting piles are [5,4,5].
- Apply the operation on pile 0. The resulting piles are [3,4,5].
The total number of stones in [3,4,5] is 12.
 */


public class RemoveStonesToMinimizeTotal {
	 public int minStoneSum(int[] piles, int k) {
			/*
			 * List<Integer> ls=new ArrayList<>(); for(int i:piles) ls.add(i);
			 * Collections.sort(ls); int sum=0; while(k>0) { int i=ls.size()-1;
			 * if(k==0)break; else { int tmp=ls.get(i); tmp-=(int)Math.floor(tmp/2);
			 * ls.remove(i); ls.add(tmp); k--; } } for(int i:ls) sum+=i;
			 * 
			 * return sum;
			 */
	        
	        
		
		 PriorityQueue<Integer> pq = new PriorityQueue<>((a,b)->b-a);
		 
	        for(int x: piles)
	        {
	            pq.add(x);
	        }
	        System.out.println(pq);
	        while(k>0 && !pq.isEmpty())
	        {
	            int temp=pq.poll();
	            temp-=(int)Math.floor(temp/2);
	            pq.add(temp);
	            k--;
	        }
	        System.out.println(pq);
	        int sum=0;
	        while(!pq.isEmpty())
	        {
	            sum+=pq.poll();
	        }
	        
	        return sum;
	        
	    }
	 public int minStoneSum2(int[] piles, int k) {
		 	Queue<Integer> queue=new PriorityQueue<>(Collections.reverseOrder());
		 	for(int i:piles)
		 		queue.add(i);
		 	
		 	while(k>0) {
		 		int temp=queue.poll();
		 		temp-=temp/2;
		 		queue.add(temp);
		 		k--;
		 	}
		 	int sum=0;
		 	for(int i:queue)
		 		sum+=i;
		 	
		 	return sum;
		 	
		 	
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoveStonesToMinimizeTotal r=new RemoveStonesToMinimizeTotal();
		int[] piles= {4,3,6,7};
		int k=3;
		System.out.println(r.minStoneSum(piles, k));
		System.out.println(r.minStoneSum2(piles, k));
		
	}

}
