package com.demo.leetcode;

import java.util.HashSet;
import java.util.Set;

public class LongestSubstringWithoutRepeatingCharacters {

	public static void getLongestSubstring(String s) {
		Set<Character> ls=new HashSet<>();
		int count=0,maxLen=0;
		for(int i=0;i<s.length();i++) {
			char c=s.charAt(i);
			if(ls.contains(c)) {
				ls.clear();
				ls.add(c);
				if(count>maxLen)
					maxLen=count;
				count=1;
			}
			else {
				ls.add(c);
				count++;
			}
		}
		System.out.println(maxLen >count?maxLen:count);
		
	}
	
	//working
	public static void getLongestSubstring2(String s) {
		int i=0,j=0,maxLen=0;
		Set<Character> ch=new HashSet<>();
		
		while(j<s.length()) {
			char c=s.charAt(j);
			
			if(!(ch.contains(c))) {
				ch.add(c);
				j++;
				maxLen=Math.max(maxLen, ch.size());
			}
			else
				ch.remove(s.charAt(i++));
		}
		System.out.println(maxLen);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*getLongestSubstring("abcabcbb");
		getLongestSubstring("bbbbbb");*/
		getLongestSubstring2("pwwkew");
		getLongestSubstring2("dvdf");
	}

}
