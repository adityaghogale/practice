package com.demo.leetcode;

import java.util.HashMap;
import java.util.Map;

public class IsomorphicString {

	public static boolean isIsomorphic(String s, String t) {
        
		if(s.length() == t.length()) {
		Map<Character,Character> chMap=new HashMap<>();
		for(int i=0;i<s.length();i++) {
			if(chMap.containsKey(s.charAt(i))) {
				if(!(chMap.get(s.charAt(i))==t.charAt(i)))
					return false;
				}
			else if(chMap.containsValue(t.charAt(i))) {
				if(!(chMap.containsKey(s.charAt(i))))
					return false;
					
			}
			else
				chMap.put(s.charAt(i),t.charAt(i));
			}
		return true;
		}
		else return false;
		
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(isIsomorphic("badc", "bcad"));
	}

}
