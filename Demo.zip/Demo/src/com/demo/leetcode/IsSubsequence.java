package com.demo.leetcode;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * A subsequence of a string is a new string that is formed from the original string by deleting some 
 * (can be none) of the characters without disturbing the relative positions of the remaining 
 * characters.
 *  (i.e., "ace" is a subsequence of "abcde" while "aec" is not).
 * */
public class IsSubsequence {


	public boolean isSubsequence(String s, String t) {
		if(s.length()==0)return true;
	        if(t.length()==0 )return false;
	        if(s.length() == t.length() && !(s.equals(t)))return false;
       int i=0,j=0;
       while(j<t.length() && i<s.length()) {
    	   if(s.charAt(i) == t.charAt(j))
    		   i++;
    	   j++;
       }
   
       return i== s.length();
        	
    }
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IsSubsequence s=new IsSubsequence();
		System.out.println(s.isSubsequence("b", "abc"));
		
	}

}
