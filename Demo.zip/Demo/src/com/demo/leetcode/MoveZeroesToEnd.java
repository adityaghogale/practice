package com.demo.leetcode;

import java.util.Arrays;

public class MoveZeroesToEnd {

	 public static void moveZeroes(int[] nums) {
		 	int j=0;
	        int[] k=new int[nums.length];
	        for(int i=0;i<nums.length;i++) {
	        	if(nums[i] == 0)continue;
	        	k[j++]=nums[i];
	        }
	        System.out.println(Arrays.toString(k));
	    }
	 
	 public static void moveZero(int[] nums) {
		 int j=0,temp;
		 for(int i=0;i<nums.length;i++) {
			 if(nums[i]!=0) {
				 	temp = nums[j];
		            nums[j] = nums[i];
		            nums[i] = temp;
		            j++;
			 }
		 }
		 System.out.println(Arrays.toString(nums));
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		moveZeroes(new int[] {0,1,0,3,2,4});
		moveZero(new int[] {1,0,2,3,0,4,5,6,0,7,8,9,10});
	}

}
