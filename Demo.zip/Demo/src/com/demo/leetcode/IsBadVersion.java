package com.demo.leetcode;

public class IsBadVersion {

	//my solution
	public static int firstBadVersion(int n) {
		if(n<=0 || !isBadVersion(n))
			return -1;
		if(isBadVersion(1))
			return 1;
		
        int left=1,right=n,mid;
        while(left<right){
            mid=left+(right-left)/2;
            if(isBadVersion(mid))right=mid;
            else left=mid+1;
        }
        return left;
    }
	
	
	public static boolean isBadVersion(int n) {
		return n>=1702766719;
	}
	
	//another 
	public static int firstBadVersion2(int n) {
		if (isBadVersion(1)) {
			return 1;
		}

		int i = 1;
		int j = n;

		while (i < j) {
			int mid = (i + (j - i) / 2)+1;
			if (!isBadVersion(mid)) {
				i = mid;
			} else {
				j = mid - 1;
			}
		}

		return j + 1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(firstBadVersion(2126753390));
	}

}
