package com.demo.leetcode;

import java.util.Stack;

public class ValidPalindrome {

	//my method
	 public static boolean isPalindrome(String s) {
	     int i=0;
	     s=s.toLowerCase();
	     s=s.replaceAll("[^0-9a-z]+","");
	     System.out.println(s);
	     int j=s.length()-1;
	     while(i<s.length()-1) {
	    	 if(s.charAt(i) != s.charAt(j))
	    		 return false;
	    	 else {
	    		 i++;j--;
	    	 }
	     }
	     
		 return true;
	    }
	 
	 
	 //faster method
	 public static boolean isPalindrome2(String s) {
		 int i=0,j=s.length()-1;
		 char iChar,jChar;
		 while(i<j) {
			 iChar=s.charAt(i);
			 jChar=s.charAt(j);
			 if((Character.isLetterOrDigit(iChar))) {
				 if((Character.isLetterOrDigit(jChar))) {
					 if(Character.toLowerCase(iChar) !=Character.toLowerCase(jChar))
					 return false;
				 else {
					 
					 i++;j--;
				 }
			 }
			else j--;
			 }
			 else i++;
		 }
		 
		 return true;
	 }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(isPalindrome2("0P"));
		char[] charMap=new char[256];
		for(int i=0;i<26;i++){
	        charMap[i+'a'] = charMap[i+'A'] = (char)(11+i);  //alphabetic, ignore cases
	    }
		for(int i=0;i<26;i++){
			System.out.println(charMap[i]);
		}
	
	}

}
