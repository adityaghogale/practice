package com.demo.leetcode;

import java.util.HashSet;
import java.util.Set;

public class RepeatedSubstringPattern {
	public static boolean repeatedSubstringPattern(String s) {
        if(!(s.length() %2 == 0)) 
        	return false;
        else {
        	String ss="";
        	for(int i=0;i<s.length();i++) {
        		if(!(ss.indexOf(s.charAt(i)+"")>-1)) {
        			ss+=s.charAt(i);
        		}
        		else break;	
        	}
        	int j=ss.length()-1;
        	for(int i=s.length()-1;i>=ss.length();i--) {
        		if(s.charAt(i) == ss.charAt(j)) {
        			j--;
        			if(j<0)j=ss.length()-1;
        		}
        		else
        			return false;
        	}
        }
       
        return true;
    }
	
	public static void main(String[] args) {
		System.out.println(repeatedSubstringPattern("abcabcabcabc"));
	}
}
