package com.demo.leetcode;

import java.util.Arrays;
import java.util.Collections;

public class SquareOfSortedArray {

	public static int[] getArray(int[] arr) {

		int[] ar = new int[arr.length];
		int i = 0, j = arr.length - 1;
		for (int p = arr.length - 1; p > 0; p--) {
			if (Math.abs(arr[i]) >= Math.abs(arr[j])) {
				ar[p] = arr[i] * arr[i];
				i++;
			} else {
				ar[p] = arr[j] * arr[j];
				j--;
			}
		}
		return ar;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Arrays.toString(getArray(new int[] { -4, -1, 0, 3, 10 })));
	}

}
