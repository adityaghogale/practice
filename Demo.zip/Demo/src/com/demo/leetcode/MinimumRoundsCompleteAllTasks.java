package com.demo.leetcode;

import java.util.HashMap;
import java.util.Map;

public class MinimumRoundsCompleteAllTasks {

	public static int minimumRounds(int[] tasks) {
		Map<Integer, Integer> mp = new HashMap<>();
		for (int i : tasks)
			mp.put(i, mp.getOrDefault(i, 0) + 1);
		int count = 0;

		for (Map.Entry<Integer, Integer> tmp : mp.entrySet()) {
			int tmpVal=tmp.getValue();
			if(tmpVal ==1)return -1;
			count+=tmpVal/3;
			/*
			We can have 1 or 2 tasks remaining. We're not supposed to take task of count 1, but we can 'borrow' 1 from the previous
			ex. [5,5,5,5,5,5,5] -> [5,5,5][5,5,5][5]
			In this example, treat the last [5,5,5], [5] as [5,5], [5,5]
			*/
			if(tmpVal%3 !=0)count++;
		}

		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	System.out.println(minimumRounds(new int[] { 2, 2, 3, 3, 2, 4, 4, 4, 4, 4 }));
		System.out.println(minimumRounds(new int[] { 3, 3,3,3,3,3 }));
		
		System.out.println(5%3);
	}

}
