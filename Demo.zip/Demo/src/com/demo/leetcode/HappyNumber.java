package com.demo.leetcode;

import java.util.Arrays;

public class HappyNumber {

	// Floyd Cycle detection algorithm.
	public static boolean isHappy(int n) {
		if(n<0)return false;
		int fast,slow;
		fast=slow=n;
		do {
			slow=getSum(slow);
			fast=getSum(getSum(fast));
		}while(slow !=fast);
		if(slow==1)return true;
		else return false;
		
		
    }
	public static int getSum(int n) {
		int sum = 0;
		while(n>0) {
			sum+=(int) Math.pow(n%10,2);
			n=n/10;
		}
		return sum;
	}
	
	
	//my logic
	public static boolean isHappy2(int n) {
		if(n<0)return false;
		int sum = 0,tmpSum=0;
		while(true) {
			if(n==1 || n==7 )return true;
			while(n>0) {
				sum+=(int) Math.pow(n%10,2);
				n=n/10;
			}
			if(sum == 1) return true;
			if(sum == tmpSum)return false;
			if(sum<10)tmpSum=sum;
			n=sum; 	
			sum=0;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(isHappy(11));
		
	}

}
