package com.demo.leetcode;

import java.util.Arrays;

public class FindPivotIndex {

	public static int pivotIndex(int[] nums) {
		System.out.println(Arrays.toString(nums));
		int i = 1;
		int j = nums.length - 2;
		int leftSum = nums[0], rightSum = nums[nums.length - 1];
		while (i <= j) {
			System.out.println("RSUm "+rightSum+" lSUm:"+leftSum);
			 	if(leftSum ==rightSum)
	                return i;
	            else if(leftSum > rightSum)
	                rightSum+=Math.abs(nums[j--]);
	            else
	                leftSum+=Math.abs(nums[i++]);
			}
		
		return -1;
	}
	
	public static int pivotIndex2(int[] nums) {
		int i=0,j=nums.length-1;
		int lSum=nums[i],rSum=nums[j];
		while(i!=j) {
			if(lSum>rSum)
				rSum+=Math.abs(nums[--j]);
			else
				lSum+=Math.abs(nums[++i]);
			if(lSum==rSum)return i+1;
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(pivotIndex2(new int[] {1,2,3}));
	}

}
