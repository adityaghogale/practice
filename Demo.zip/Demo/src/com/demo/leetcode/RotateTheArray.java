package com.demo.leetcode;

import java.util.Arrays;

public class RotateTheArray {

	 public void rotate(int[] nums, int k) {
	        int[] p=new int[nums.length];
	        int j=0;
	        for(int i=nums.length-k;i<nums.length;i++) {
	        	p[j++]=nums[i];
	        }
	        for(int i=0;i<nums.length-k;i++) {
	        	p[j]=nums[i];
	        	j++;
	        }
	        System.out.println(Arrays.toString(p));
	    }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RotateTheArray r=new RotateTheArray();
		r.rotate(new int[] {1,3,4,5,6,2},3);
	}

}
