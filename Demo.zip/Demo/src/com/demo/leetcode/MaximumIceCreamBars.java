package com.demo.leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/*
At the store, there are n ice cream bars. 
You are given an array costs of length n, 
where costs[i] is the price of the ith ice cream bar in coins. 
The boy initially has coins coins to spend, and he wants to buy as many ice cream 
bars as possible. 
Return the maximum number of ice cream bars the boy can buy with coins coins.

Input: costs = [1,3,2,4,1], coins = 7
Output: 4
Explanation: The boy can buy ice cream bars at indices 0,1,2,4 
for a total price of 1 + 3 + 2 + 1 = 7.

*/
public class MaximumIceCreamBars {

	static public int maxIceCream(int[] costs, int coins) {
        Arrays.sort(costs);
        int count=0;
        for(int i=0;i<costs.length;i++){
            if((coins-costs[i])>0){
                coins=coins-costs[i];
                count++;
            }
            else if(coins<costs[i])
            break;
            
        }
        return count;
    }

	static public int maxIceCream2(int[] costs, int coins) {
		 List<Integer> ls=new ArrayList<>();
			for(int i:costs)
				ls.add(i);
	       int count=0;
	       Collections.sort(ls);
	       for(Integer i:ls) {
	    	 if(i == 0)count++;
	    	 else if((coins-i)>=0) {
	    		 count++;
	    		 coins-=i;
	    	 }
	    	 else break;
	       }
	       return count;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] costs= {4,7,6,4,4,2,2,4,8,8};
		int coins=41;
		System.out.println(maxIceCream2(costs, coins));
	}

}
