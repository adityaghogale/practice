package com.demo.leetcode;

public class IntToRoman {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1=new String("Hello");
		String s2="Hello";
		String s3=s2+"jadu";
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println(s3==s2);
		System.out.println("s2 "+s2);
		String s4=s1;
		//s4=s4+"bro";
		System.out.println(s4==s1);
		System.out.println(s4.equals(s1));
		
	}

}
