package com.demo.leetcode;

import java.util.Stack;

public class AddBinary {

	static String getBinarySum(String s1,String s2) {
		int i=s1.length()-1,j=s2.length()-1;
		int carry=0;
		StringBuilder sb=new StringBuilder();
		while(i>=0 || j>=0 || carry!=0){
			if(i>=0) 
				carry+=s1.charAt(i--)-'0';
			if(j>=0) 
				carry+=s2.charAt(j--)-'0';
			sb.append((carry%2));
			carry/=2;
		}
		
		return sb.reverse().toString();
	}
	public static void main(String[] args) {
		String s1="0";
		String s2="0";
		System.out.println(getBinarySum(s1, s2));
	}
}
