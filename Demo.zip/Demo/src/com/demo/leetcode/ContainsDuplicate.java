package com.demo.leetcode;

import java.util.HashMap;
import java.util.Map;

public class ContainsDuplicate {

	//faster
	public boolean containsDuplicate2(int[] nums) {
		
		Map<Integer,Integer> tmpMap=new HashMap<>();
		for(int i=0;i<nums.length-1;i++) {
			if(tmpMap.containsKey(nums[i]))
				return true;
			tmpMap.put(nums[i], nums[i]);
		}
		return false;
		
	}
	
	//slower
		public boolean containsDuplicate(int[] nums) {
			
			Map<Integer,Integer> tmpMap=new HashMap<>();
			for(int i=0;i<nums.length-1;i++) {
				if(tmpMap.containsKey(nums[i]))
					return true;
				tmpMap.put(nums[i], nums[i]);
			}
			return false;
			
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
