package com.demo.leetcode;

import java.util.Stack;

public class BalanceParentheses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My Solution for (){}}{ "+isBalanced("(){}}{"));
		System.out.println("Short Solution for (){}}{ "+isBalanced2("(){}}{"));
	}

	//My Solution
	public static boolean isBalanced(String s) {
		 Stack<Character> brackets=new Stack<>();
			char ch;
			for(int i=0;i<s.length();i++) {
				ch=s.charAt(i);
				switch(ch) {
				case '}':if(!(brackets.isEmpty()) && brackets.peek() == '{')brackets.pop();
						else brackets.push(ch);
						break;
						
				case ')':if(!(brackets.isEmpty()) && brackets.peek() == '(')brackets.pop();
						else brackets.push(ch);
						break;
						
				case ']':if(!(brackets.isEmpty()) && brackets.peek() == '[')brackets.pop();
						else brackets.push(ch);
						break;
				default : brackets.push(ch);
				}
				
			}
			if(brackets.isEmpty())return true;
			else return false;
	}
	
	//More efficient
	public static boolean isBalanced2(String s) {
	Stack<Character> stk=new Stack<>();
	char ch;
	for(int i=0;i<s.length();i++) {
		ch=s.charAt(i);
		if(ch == '(' ||ch == '{' ||ch == '[' )stk.push(ch);
		else if(stk.isEmpty())return false;
		else if(ch == ')' && stk.pop() =='(')return true;
		else if(ch == '}' && stk.pop() =='{' )return true;
		else if(ch == ']' && stk.pop() =='[')return true;	
	}
	return false;
	}
	
	//Short solution
	public static boolean isBalanced3(String s) {
		int length;
		do {
			length=s.length();
			s.replace("()","").replace("{}","").replace("[]","");
		}while(length !=s.length());
		return s.length() == 0;
	}
	
}
