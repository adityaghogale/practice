package com.demo.leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MinimumSumofFourDigitNumber {

	 public int minimumSum(int num) {
		 int[] a=new int[4];
		 int i=0;
		 while(num!=0) {
			 a[i++]=num%10;
			 num/=10;
		 }
		 Arrays.sort(a);
		 return a[0]*10+a[1]*10+a[2]+a[3];
	        
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MinimumSumofFourDigitNumber m=new MinimumSumofFourDigitNumber();
		
		System.out.println(m.minimumSum(4009));
	}

}
