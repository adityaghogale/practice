package com.demo.leetcode;

import java.util.HashMap;
import java.util.Map;

public class RomanToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(romanToInt("MCMXC"));
	}

	public static int romanToInt(String s) {
		int value=0;
		Map<Character,Integer> intValue=new HashMap<>();
		intValue.put('I', 1);
		intValue.put('V', 5);
		intValue.put('X', 10);
		intValue.put('L', 50);
		intValue.put('C', 100);
		intValue.put('D', 500);
		intValue.put('M', 1000);
		
		char tmpChar;
		for(int i=0;i<s.length()-1;i++) {
			tmpChar=s.charAt(i);
			if(i == s.length()-1) {
				value=value+intValue.get(tmpChar);
				break;
			}
				
			switch(tmpChar) {
			case 'I':
				if('V'==s.charAt(i+1)) {value+=4;i++;}
				else if('X'==s.charAt(i+1)) {value+=9;i++;}
				else value+=1;
					break;
			case 'X':
				if('L'==s.charAt(i+1)) {value+=40;i++;}
				else if('C'==s.charAt(i+1)) {value+=90;i++;}
				else value+=10;
				
				break;
			case 'C':
				if('D'==s.charAt(i+1)){value+=400;i++;}
				else if('M'==s.charAt(i+1)){value+=900;i++;}
				else value+=100;
				break;
			default :
				value=value+intValue.get(tmpChar);	
			}
		}
		return value;
	}
	
}
