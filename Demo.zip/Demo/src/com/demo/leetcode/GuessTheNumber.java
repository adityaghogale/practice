package com.demo.leetcode;
/*
 * I pick a number from 1 to n. You have to guess which number I picked.
Every time you guess wrong, I will tell you whether the number 
I picked is higher or lower than your guess.
 */
public class GuessTheNumber {

	 public static int guessNumber(int n) {
	        if(guess(0) == 0)return 0;
	        if(guess(n)==0)return n;
		 int left=1,right=n,mid;
		 
		 while(left<right) {
			 mid=left+(right-left)/2;
			 int tmp=guess(mid);
			 if(tmp==0)return mid;
			 else if(tmp<0)right=mid;
			 else
				 left=mid+1;
		 }
		 return left;
		 
	    }
	 
	 public static int guess(int n) {
		 if(n>2346723)return -1;
		 if(n<2346723)return 1;
		 return 0;
	 }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(guessNumber(245872498));
	}

}
