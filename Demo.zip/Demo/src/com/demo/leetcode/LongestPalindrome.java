package com.demo.leetcode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LongestPalindrome {

	//slower
	 public int longestPalindrome(String s) {
		 if(s.length() ==1)return 1;
		 int count=0;
	   Map<Character,Integer> mp=new HashMap<>();
	   for(char c:s.toCharArray()) {
		  mp.put(c, mp.getOrDefault(c, 0)+1);
	   }
	   for(int i:mp.values()) {
		   if(i%2 == 0)count+=i;
		   else count+=i-1;
	   }
	   return count<s.length()?count+1:count;
	  }
	 
	 //faster
	 public int longestPalindrome2(String s) {
	 int count=1;
		Set<Character> hs=new HashSet<>(); 
		for(char c:s.toCharArray()) {
			if(hs.contains(c)) {
				hs.remove(c);
				count++;
			}
			else
				hs.add(c);
		}
		if(!hs.isEmpty())return count*2+1;
		return count*2;
	 }
	 
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(4%2);
		LongestPalindrome lp=new LongestPalindrome();
		System.out.println(lp.longestPalindrome("xxx"));
	}

}
