package com.demo.leetcode;

public class CharInLastWordOfString {

	static public int countChar(String s) {
		int count = 0;
		for(int i=s.length()-1;i>=0;i--) {
			if(s.charAt(i) !=' ')
				count++;
			else
				if(count>0)return count;
		}
		return count;
	}

	static public int countChar2(String s) {
		int count=0;
		int lastPos=0;
		for(int i=s.length()-1;i>=0;i--) {
			if(s.charAt(i) != ' ') {
					lastPos=i;
					break;
			}
		}
		for(int i=lastPos;i>=0;i--) {
			if(s.charAt(i) != ' ') 
				count++;
			else break;
		}
		return count;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Luffy is still joyboy";
		String s1 = "aditya   ";
		System.out.println("Number of char = " + countChar(s1));
	}

}
