package com.demo.leetcode;

public class LongestCommonPrefix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] s=new String[]{"flower","flow","flight"};
		System.out.println(longestCommonPrefix2(s));
	}
	 public static String longestCommonPrefix(String[] strs) {
		 if(strs.length == 1)return strs[0];
	        String s=strs[0],tmpStr="";
		        boolean flag=true;
		        for(int j=0;j<=s.length();j++) {
		        	tmpStr=s.substring(0,j);
		        for(int i=1;i<strs.length;i++){
		            if(!(strs[i].startsWith(tmpStr))) {
	                    tmpStr=s.substring(0,j-1);
		            	flag=false;
		            	break;
		            }
		        }
		        if(!flag) {
		        	break;}
		        }
		        return tmpStr;
	    }
	 public static String longestCommonPrefix2(String[] strs) {
		 if(strs.length == 1)return strs[0];
	        String s=strs[0];
	        StringBuilder sb=new StringBuilder();
		        boolean flag=true;
		        for(char c:s.toCharArray()) {
		        	sb.append(c);
		        for(int i=1;i<strs.length;i++){
		            if(!(strs[i].startsWith(sb.toString()))) {
	                    sb.replace(sb.length()-1, sb.length(),"");
		            	flag=false;
		            	break;
		            }
		        }
		        if(!flag) {
		        	break;}
		        }
		        return sb.toString();
	    }

}
