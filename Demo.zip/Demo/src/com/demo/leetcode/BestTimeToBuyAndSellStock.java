package com.demo.leetcode;

public class BestTimeToBuyAndSellStock {

	public static int maxProfit(int[] prices) {
		if(prices.length == 1)return 0;
		int min=Integer.MAX_VALUE,maxProf=0,max=0,pos=0;
		for(int i=0;i<prices.length;i++) {
			if(prices[i]<min) {
				min=prices[i];
				pos=i;
				max=min;
			}
			if(max<prices[i] && i>pos) {
				int tmaxProf=prices[i]-min;
				if(tmaxProf >= maxProf)maxProf=tmaxProf;
			}
		}
		if(pos==prices.length-1 && maxProf==0)return 0;
		return maxProf;
		
	}
	
	public static int maxProfit2(int[] prices) {
		
		int min=Integer.MAX_VALUE;
		int maxProf=0,tmp;
		for(int i=0;i<prices.length;i++) {
			if(prices[i]<min)min=prices[i];
			tmp=prices[i]-min;
			if(maxProf<tmp)maxProf=tmp;
		}
		return maxProf;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(maxProfit2(new int[] {1,2}));
	}

}
