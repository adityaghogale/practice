package com.demo.leetcode;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class RemoveVovelsFromString {
	
	public static String removeVovels(String s) {
		StringBuilder sb=new StringBuilder();
		Set<Character> st=new HashSet<>(Arrays.asList('a','e','i','o','u','A','E','I','O','U'));
		for(int i=0;i<s.length()-1;i++) {
			if(!st.contains(s.charAt(i))) {
				sb.append(s.charAt(i));
			}
		}
		
		return sb.toString();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(removeVovels("Hello"));
	}

}
