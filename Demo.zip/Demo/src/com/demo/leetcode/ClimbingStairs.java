package com.demo.leetcode;

import java.util.List;

/*You are climbing a staircase. It takes n steps to reach the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?
Input: n = 2
Output: 2
Explanation: There are two ways to climb to the top.
1. 1 step + 1 step
2. 2 steps
*/
public class ClimbingStairs {

	public static int climbStairs(int n) {
		int a=0,b=1,count=0;
		for(int i=0;i<n;i++) {
			count=a+b;
			a=b;
			b=count;
		}
		return count;
    
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(climbStairs(4));
		
	}

}
