package com.demo.leetcode;

public class LongestPalindromeString {

	
	//time consuming
	public static void longestPalindrome2(String s) {
		int maxLen=0;
		 String ss=""; 
		 for(int j=0;j<s.length();j++) {
		 for (int i=j+1;i<s.length();i++) {
			 String s1=s.substring(j,i+1);
			 String s2=new StringBuilder(s1).reverse().toString();
			 if(s1.equals(s2)) {
				 if(s1.length()>maxLen) {
					 maxLen=s1.length();
				 ss=s1;
				 }
			 }
		 }
		 }
		 System.out.println(ss);
		 
	 }
	
	
	public static void longestPalindrome(String s) {
		String tmpAns="";
		String ans="";
		String ss=new StringBuilder(s).reverse().toString();
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i) == ss.charAt(i)) {
				tmpAns+=s.charAt(i);
			}
			else {
				if(tmpAns.length() > ans.length()) {
					ans=tmpAns;
					tmpAns="";
				}
			}
		}
		System.out.println(ans);
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		longestPalindrome("cbbac");
	}

}
