package com.demo.leetcode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/*[Medium]
 You have n bags numbered from 0 to n - 1.
  You are given two 0-indexed integer arrays capacity and rocks. 
  The ith bag can hold a maximum of capacity[i] rocks and currently contains rocks[i] 
  rocks. You are also given an integer additionalRocks, 
 the number of additional rocks you can place in any of the bags.
 
 Input: capacity = [2,3,4,5], rocks = [1,2,4,4], additionalRocks = 2
Output: 3
Explanation:
Place 1 rock in bag 0 and 1 rock in bag 1.
The number of rocks in each bag are now [2,3,4,4].
Bags 0, 1, and 2 have full capacity.
There are 3 bags at full capacity, so we return 3.
It can be shown that it is not possible to have more than 3 bags at full capacity.
Note that there may be other ways of placing the rocks that result in an answer of 3.
 */


public class MaximumBagsWithFullOfRocks {

	//correct
	 public int maximumBags(int[] capacity, int[] rocks, int additionalRocks) {
	       List<Integer> ls=new ArrayList<>();
	       for(int i=0;i<capacity.length;i++) {
	    	   if(!(capacity[i]-rocks[i]>additionalRocks))
	    	   ls.add(capacity[i]-rocks[i]);
	       }
	       int count=0;
	       Collections.sort(ls);
	       for(Integer i:ls) {
	    	 if(i == 0)count++;
	    	 else if((additionalRocks-i)>=0) {
	    		 count++;
	    		 additionalRocks-=i;
	    	 }
	    	 else break;
	       }
	       return count;
	    }
	
	 //does'nt work
	 public int maximumBags2(int[] capacity, int[] rocks, int additionalRocks) {
	       Map<Integer,Integer> mp=new TreeMap<>();
	       for(int i=0;i<capacity.length;i++) {
	    	   int diff=capacity[i]-rocks[i];
	    	   if(!(diff>additionalRocks))
	    		   mp.put(diff, mp.getOrDefault(diff, 0)+1);
	       }
	       int count=0;
	       for(Integer i:mp.keySet()) {
	    	   int qty=mp.get(i);
	    	   if(additionalRocks-i*qty >0) {
	    		   additionalRocks-=i*qty;
	    		   count+=qty;
	    		continue;   
	    	   }
	    	   int k=qty;
	    	   while(additionalRocks >0 && additionalRocks > i) {
	    		   additionalRocks-=i;
	    		   count++;
	    	   }
	       }
	       return count;
	    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaximumBagsWithFullOfRocks m=new MaximumBagsWithFullOfRocks();
		int[] capacity= {54,18,91,49,51,45,58,54,47,91,90,20,85,20,90,49,10,84,59,29,40,9,100,1,64,71,30,46,91};
		int[] rocks= {14,13,16,44,8,20,51,15,46,76,51,20,77,13,14,35,6,34,34,13,3,8,1,1,61,5,2,15,18};
		int additionalRocks=77;
		
		System.out.println(m.maximumBags2(capacity, rocks, additionalRocks));
	}

}
