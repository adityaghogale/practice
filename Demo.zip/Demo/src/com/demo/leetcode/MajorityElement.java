package com.demo.leetcode;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/*Given an array of size n, return the majority element.

The majority element is the element that appears more than [n / 2] times. 
You may assume that the majority element always exists in the array.

*/

public class MajorityElement {

	public static int majorityElement(int[] nums) {
		Arrays.sort(nums);
		return nums[nums.length/2];
    }
	
	public static int majorityElement2(int[] nums) {
		//if(nums.length == 1)return nums[0];
		 Map<Integer,Integer> mp=new HashMap<>();
	        int maxOcc=0,ele=0;
	      for(int a:nums)
	    	  mp.put(a, mp.getOrDefault(a,1)+1);
	        
	        for(Integer a:mp.keySet()) {
	        	if(maxOcc<mp.get(a)) {
	        		ele=a;
	        		maxOcc=mp.get(a);
	        	}
	        		
	        }
	        return ele;
	        
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(majorityElement2(new int[] {1,2,4,5,4,2,3,1,3,1}));
		int[] ars=new int[] {1,2,4,5,4,2,3,1,3,1};
		Arrays.sort(ars);
		System.out.println(Arrays.toString(ars));
		System.out.println(majorityElement2(new int[] {2,2,2,3,3,3,3,}));
	}

}
