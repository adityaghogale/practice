package com.demo.leetcode;

import java.util.HashMap;
import java.util.Map;

public class ContainsDuplicate2 {

	public static boolean containsNearbyDuplicate(int[] nums, int k) {
        
		Map<Integer,Integer> tmpMap=new HashMap<>();
		for(int i=0;i<nums.length;i++) {
			
			if(tmpMap.containsKey(nums[i]) && Math.abs(i-tmpMap.get(nums[i]))<=k)return true;
			tmpMap.put(nums[i], i);
			System.out.println(Math.abs(i-tmpMap.get(nums[i])));
		}
		return false;
    }
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(containsNearbyDuplicate(new int[] {1,2,1},0));
	}

}
