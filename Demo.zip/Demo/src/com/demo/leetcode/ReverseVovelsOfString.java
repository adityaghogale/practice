package com.demo.leetcode;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.print.attribute.SetOfIntegerSyntax;

//reverse only all the vowels in the string and return it.

//Input: s = "hello"
// Output: "holle"


public class ReverseVovelsOfString {

	static String reverseVovels(String s) {
		
		char[] ch=s.toCharArray();
		int i=0,j=ch.length-1;
		Set<Character> vovels=new HashSet<>();
		vovels.add('a');
		vovels.add('e');
		vovels.add('i');
		vovels.add('o');
		vovels.add('u');
		vovels.add('A');
		vovels.add('E');
		vovels.add('I');
		vovels.add('O');
		vovels.add('U');
		
		while(i<j) {
			if(vovels.contains(ch[i])) {
				if(vovels.contains(ch[j])) {
					char tmp=ch[i];
					ch[i]=ch[j];
					ch[j]=tmp;
					i++;j--;
				}
				else j--;
			}
			else if(vovels.contains(ch[j])) {
				if(vovels.contains(ch[i])) {
					char tmp=ch[i];
					ch[i]=ch[j];
					ch[j]=tmp;
					i++;j--;
				}
				else i++;
			}
			else {
				i++;j--;
			}
			
		}
		return String.valueOf(ch);
	}
	
	
	static String reverseVovels2(String s) {
		Set<Character> hs=new HashSet<>(Arrays.asList(new Character[] {'a','e','i','o','u','A','E','I','O','U',}));
		char[] ch=s.toCharArray();
		for(int i=0,j=s.length()-1;i<j;) {
			if(!hs.contains(ch[i])) {
				i++;
				continue;
			}
			else if(!hs.contains(ch[j])) {
				j--;
				continue;
			}
			char tmp=ch[i];
			ch[i]=ch[j];
			ch[j]=tmp;	
			i++;j--;
		}
		return String.valueOf(ch);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(reverseVovels2("aeiouUOIEA"));
	}

}
