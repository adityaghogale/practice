package com.demo.leetcode;

public class SquareRoot {

	//MY
	public static int mySqrt(int x) {
        int count=0,j=1;
        while(x>0 && j<=x) {
        	x-=j;
        	count++;
        	j+=2;
        }
        return count;
        
    }
	//shortest
	public static int mySqrt2(int x) {
		 long r = x;
		    while (r*r > x)
		        r = (r + x/r) / 2;
		    return (int) r;
	}
	
	//using binary search
	public static int mySqrt3(int x) {
		if (x == 0)
	        return 0;
	    int left = 1, right = x;
	    while (true) {
	        int mid = left + (right - left)/2;
	        if (mid > x/mid) {
	            right = mid - 1;
	        } else {
	            if (mid + 1 > x/(mid + 1))
	                return mid;
	            left = mid + 1;
	        }
	    }
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(mySqrt2(16));
	}

}
