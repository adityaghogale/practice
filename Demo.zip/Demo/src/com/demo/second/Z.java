package com.demo.second;

import java.io.IOException;

class B{
	void show() throws IOException {
		System.out.println("In B");
	}
}
public class Z extends B{

	void show() throws IOException{
		System.out.println("In Z");
	}
	public static void main(String[] args) throws IOException {
		B b=new Z();
		b.show();
		
	}
}
