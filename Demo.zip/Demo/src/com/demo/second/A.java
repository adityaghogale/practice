package com.demo.second;

public class A {

	public void m1() {
		try {
			synchronized(A.class){
			for(int i=0;i<3;i++) {
			Thread.sleep(2);
			System.out.println("In m1 method"+Thread.currentThread().getName());
			}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	public static void main(String[] args) {
		A a1=new A();
		A a2=new A();
		Thread t1=new Thread("Adi"){
			public void run() {
				a1.m1();
			}
		};
		
		Runnable r=()->{
			a2.m1();
		};		
		Thread t3=new Thread(r,"lucky");
		t1.start();
		t3.start();
		
	}
}

@FunctionalInterface
interface sample{
	
	public String show(int num);
}

