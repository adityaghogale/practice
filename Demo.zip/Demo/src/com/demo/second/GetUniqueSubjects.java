package com.demo.second;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GetUniqueSubjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> subList1=Arrays.asList("Maths","Physics","Chem");
		List<String> subList2=Arrays.asList("Maths","Physics","CS");
		List<String> subList3=Arrays.asList("Maths","Statistic","CS");
		List<String> subList4=Arrays.asList("Maths","Statistic","Physics");

		List<Student> lst=new ArrayList<>();
		lst.add(new Student(1,"Adi",26,subList2));
		lst.add(new Student(2,"Luffy",22,subList4));
		lst.add(new Student(3,"Zoro",26,subList3));
		lst.add(new Student(4,"Sanji",28,subList1));
		lst.add(new Student(5,"Nami",26,subList2));

		Set<String> hs=new HashSet<>();

		// get unique subjects from list of students each having list of subjects 
		for(Student s:lst) {
			for(String ss:s.getSubjects()) {
				hs.add(ss);
			}
		}
		
		// Combine two lists into one removing duplicates
		List<Integer> l1=Arrays.asList(1,3,5,7,9,1,5);
		List<Integer> l2=Arrays.asList(2,4,6,8,2,4);
		
		List<Integer> l3=new ArrayList<>();
		
		//Using loop
		  for(Integer s:l1) 
			  if(!l3.contains(s))l3.add(s); 
		  for(Integer ss:l2)
		  if(!l3.contains(ss))l3.add(ss);
		 
		 //using stream
		l3=Stream.concat(l1.stream().distinct(), l2.stream().distinct()).collect(Collectors.toList());
		
		
		l3.forEach(System.out::print);
		System.out.println();
		hs.forEach(System.out::println);
	}

}
