package com.demo.second;

import java.util.List;

public class Student {

	private int rollNo;
	private String name;
	private int age;
	private List<String> subjects;
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<String> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}
	public Student(int rollNo, String name, int age, List<String> subjects) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
		this.subjects = subjects;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", age=" + age + ", subjects=" + subjects + "]";
	}
	
	

}
