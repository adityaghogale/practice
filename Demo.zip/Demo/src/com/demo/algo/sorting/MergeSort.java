package com.demo.algo.sorting;

import java.util.Arrays;

public class MergeSort {
	
	private static int count=1;
public void merge(int[] arr, int l,int m,int r) {
		
		// Find sizes of two subarrays to be merged
		int n1=m-l+1;
		int n2=r-m;
		
		 /* Create temp arrays */
		int[] lft=new int[n1];
		int[] rgh=new int[n2];
		
		 /*Copy data to temp arrays*/
		for(int i=0;i<n1;i++)
			lft[i]=arr[l+i];
		
		for(int i=0;i<n2;i++)
			rgh[i]=arr[m+1+i];
		
		/* Merge the temp arrays */		
			
        // Initial indexes of first and second subarrays
			int i=0,j=0;
		
		 // Initial index of merged subarray array
		int k=l;
		while(i<n1 && j<n2) {
			if(lft[i]<=rgh[j]) {
				arr[k]=lft[i];
				i++;k++;
			}
			else {
				arr[k]=rgh[j];
				k++;j++;
			}
		}
		/* Copy remaining elements of L[] if any */
		while(i<n1) {
			arr[k]=lft[i];
			k++;i++;
			}

        /* Copy remaining elements of R[] if any */
		while(j<n2) {
			arr[k]=rgh[j];
			k++;j++;
		}
		
		count++;
	}

	public void sort(int[] arr,int l,int r) {
		
		if(l<r) {
			
			 // Find the middle point
			int m=l+(r-l)/2;
			
			// Sort first and second halves
			 sort(arr,l,m);
			 sort(arr,m+1,r);
			 
			// Merge the sorted halves
			 merge(arr,l,m,r);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MergeSort ms=new MergeSort();
		int[] arr=new int[]{2,5,3,4,1};
		System.out.println(Arrays.toString(arr));
		ms.sort(arr, 0, arr.length-1);
		System.out.println(Arrays.toString(arr));
		
		System.out.println(count);
	}

}
