package com.demo.algo.sorting;

import java.util.Arrays;

public class InsertionSort {

	public static void insertionSort(int[] arr) {
		int n=arr.length,count=0;
		for(int i=1;i<n;++i) {
			int tmp=arr[i];
			int j=i-1;
			while (j >= 0 && arr[j] > tmp) {
					arr[j+1]=arr[j--];
				count++;
			}
			arr[j+1]=tmp;
		}
		System.out.println(Arrays.toString(arr));
		System.out.println("Steps ="+count);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		insertionSort(new int[] {3,2,5,6,1,8,3,1});
	}

}
