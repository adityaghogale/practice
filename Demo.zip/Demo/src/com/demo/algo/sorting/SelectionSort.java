package com.demo.algo.sorting;

import java.util.Arrays;

public class SelectionSort {

	public static int[] selectionSort(int[] ar) {
		int mp,count=0;
		for(int i=0;i<ar.length-1;i++) {
			mp=i;
			for(int j=i+1;j<ar.length;j++) {
				if(ar[mp]>ar[j])mp=j;
				count++;
			}

			int tmp=ar[mp];
			ar[mp]=ar[i];
			ar[i]=tmp;
		}
		System.out.println("Loop count ="+count);
		return ar;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Arrays.toString(selectionSort(new int[] {3,2,5,6,1,8,3,1})));
	}

}
