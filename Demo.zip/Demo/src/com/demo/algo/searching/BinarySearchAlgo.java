package com.demo.algo.searching;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BinarySearchAlgo {

	public static int usingRecursion(int[] arr,int lft,int rght,int ele) {
		
		if(rght>=lft) {
			int mid=lft+(rght-1)/2;
			if(arr[mid] == ele)return mid;
			else if(arr[mid] > ele)
				return usingRecursion(arr,lft,mid-1,ele);
		
				return usingRecursion(arr,mid+1,rght,ele);
		}
		return -1;
	}
	
	public static int usingShortApproach(int[] arr,int ele) {
		int lft=0,rght=arr.length-1,mid;
		while(rght-lft>1) {
			mid=(rght+lft)/2;
			if(arr[mid]<ele)lft=mid+1;
			else rght=mid;
		}
		 if (arr[lft] == ele) {
		      return lft;
		    }
		    else if (arr[rght] == ele) {
		    	return rght;
		    }
		    else {
		    	return -1;
		    }
	}
	
	//return element position if element is not there then return position where it will be
	  public static int searchInsert(int[] nums, int target) {
	        
	        int mid,l=0,r=nums.length-1;
	        while(l<=r){
	            mid=l+(r-l)/2;
	        if(nums[mid]==target)return mid;
	        else if(nums[mid]>target)r=mid-1;
	        else l=mid+1;
	        }
	        return l;
	    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ELe is at pos :"+usingRecursion(new int[] {2, 3, 4, 10, 40 }, 0, 4, 10));
		System.out.println("ELe is at pos :"+usingShortApproach(new int[] {2, 3, 4, 10, 40 },10));
		System.out.println(searchInsert(new int[] {1,3,5,6},2));
		List<Integer>l1=Arrays.asList(1,2,3);
		List<Integer>l2=Arrays.asList(1,3,4);
		List<Integer> tmpList=new ArrayList<>(l1);
		tmpList.addAll(l2);
		Collections.sort(tmpList);
		System.out.println(tmpList);
	}

}
