package com.demo.algo.searching;

import java.util.Arrays;

public class ExponentialSearch {

	static public int search(int[] arr,int x,int n) {
		if(arr[0] == x)return 0;
		int i=1;
		while(i<n && arr[i] <=x)
			i*=2;
		
		return Arrays.binarySearch(arr, i/2, i, x);
		
		//return Arrays.binarySearch(arr, i/2, Math.min(i, n-1), x);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(search(new int[] {1,2,3,4,5,6,7,8,9 },8,8));
	}

}
