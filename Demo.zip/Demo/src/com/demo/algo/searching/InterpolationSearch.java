package com.demo.algo.searching;

/**
 * Fastest search algo
 * 
 * @author aghogale
 *
 */
public class InterpolationSearch {

	public static int search(int[] arr,int ele,int lo,int hi) {
		int pos;
		if(lo<=hi && ele >=arr[lo] && ele <= arr[hi]) {
		pos=lo+(ele-arr[lo])*((hi-lo)/(arr[hi]-arr[lo]));
		
		if(ele == arr[pos])return pos;
		if(ele >arr[pos])return search(arr,ele,pos+1,hi);
		if(ele < arr[pos])return search(arr,ele,lo,pos-1);
		}
		return -1;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(search(new int[] {1,2,3,4,5,6,7,8,9 },8, 0, 8));
	}

}
