package com.demo.algo.searching;

public class TernarySearchAlgo {

	//Recursion approach
	public static int ternarySearch(int[] arr,int ele,int l,int r) {
		if(r>=l) {
			int mid1=l+(r-l)/3;
			int mid2=r-(r-l)/3;
			if(ele == arr[mid1]) return mid1;
			if(ele ==arr[mid2]) return mid2;
			if(ele <arr[mid1]) return ternarySearch(arr,ele,l,mid1-1);
			if(ele >arr[mid2])return ternarySearch(arr, ele, mid2+1,r);
			else return ternarySearch(arr, ele , mid1+1, mid2-1);
		}
		return -1;
	}

    // loop approach
	public static int ternarySearchLoop(int[] arr,int ele,int l,int r) {
		while(r>=l) {
			int mid1=l+(r-l)/3;
			int mid2=r-(r-l)/3;
			if(arr[mid1]==ele)return mid1;
			if(arr[mid2]==ele)return mid2;
			if(arr[mid1]>ele)l=mid1-1;
			if(arr[mid2]<ele)r=mid2+1;
			else {
				r=mid2-1;
				l=mid1+1;
			}
		}
		
		return -1;
	}
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Ele pos with recursion approach : "+ternarySearch(new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10 },5,0,10));
		System.out.println("Ele pos with loop approach : "+ternarySearchLoop(new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10 },5,0,10));
	}

}
