package com.demo.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorDemo {
	
	public static void main(String...args) {
		
			List<Employee> lst=new ArrayList<>();
			lst.add(new Employee(1,"Adi","Dev",35000,25));
			lst.add(new Employee(2,"Luffy","Dev",30000,26));
			lst.add(new Employee(3,"Zoro","Fin",28000,28));
			lst.add(new Employee(4,"Sanji","Fin",31000,28));
			lst.add(new Employee(5,"Ace","Log",20000,30));
			lst.add(new Employee(6,"Saboo","Log",35000,30));
			lst.add(new Employee(7,"Nami","Dev",75000,28));
			lst.add(new Employee(8,"Robin","Fin",35000,27));
			lst.add(new Employee(9,"Yamato","Log",95000,30));
			lst.add(new Employee(10,"Raju","Dev",15000,24));
			
			lst.forEach(System.out::println);
			System.out.println("---------------------------");
			// For this classes are created below
			SortByName sbn=new SortByName();
			Collections.sort(lst,sbn);
			lst.forEach(System.out::println);
			System.out.println("######################################");
			lst.forEach(System.out::println);
			System.out.println("---------------------------");
			// For this classes are created below
			SortBySalary sbs=new SortBySalary();
			Collections.sort(lst,sbs);
			lst.forEach(System.out::println);
	}

}

class SortBySalary  implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		int salaryComparison= (int) (o1.getSalary()-o2.getSalary());
		if( salaryComparison == 0)
			return o1.getAge()-o2.getAge();
		return salaryComparison;
	}
	
}
class SortByName implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getName().compareTo(o2.getName());
	}
	
}


