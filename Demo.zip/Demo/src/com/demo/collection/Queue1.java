package com.demo.collection;

import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Queue;

public class Queue1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PriorityQueue<String> qu=new PriorityQueue<>();
		qu.add("Aditya");
		qu.add("Luffy");
		qu.add("Zoro");
		qu.add("Sanji");
		qu.add("Ace");
		qu.add("Sabo");
		
		qu.forEach(System.out::println);
		
		PriorityQueue<Integer> q=new PriorityQueue<>();
		q.add(5);
		q.add(7);	
		q.add(2);
		q.add(1);
		q.add(3);
		
		//get first element of queue
		System.out.println(q.element());
		
		//get highest priority element of queue and will remove it
		System.out.println(q.poll());
		System.out.println(q);
		
		//get highest priority element of queue and won't remove it
		System.out.println(q.peek());
		q.add(4);
		System.out.println(q);
	}

}
