package com.demo.collection;
/**
 * 
 * @author aghogale
 * Accept 2 words from user and return random word without storing word
 *
 */
public class RandomWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
