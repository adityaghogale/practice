package com.demo.collection;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public class DequeArrayDequeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Deque<String> qu=new ArrayDeque<>();
		qu.add("Aditya");
		qu.add("Luffy");
		qu.add("Zoro");
		qu.add("Sanji");
		qu.add("Ace");
		qu.add("Sabo");
		System.out.println(qu);
		System.out.println("Fetch and remove first element : "+qu.pollFirst());
		System.out.println(qu);
		System.out.println("Fetch and remove last element : "+qu.pollLast());
		System.out.println(qu);
		
		System.out.println("Descending iterator");
		Iterator itr=qu.descendingIterator();
		while(itr.hasNext())
			System.out.println(itr.next());
	}

}
