package com.demo.collection;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test {
	public static int countingValleys(int steps, String path) {
		// Write your code here
		int vCount = 0, seaLevel = 0, flag = 0;
		char[] chAr = path.toCharArray();
		for (char ch : chAr) {
			if (ch == 'U')
				seaLevel++;
			else
				seaLevel--;
			if (seaLevel < -1 && flag == 0) {
				vCount++;
				flag = 1;
			}
			if (seaLevel == 0)
				flag = 0;
		}
		return vCount;
	}

	public static int pickingNumbers(List<Integer> a) {
		// Write your code here
		int count = 1, maxSize = 0;
		a = a.stream().sorted((x, y) -> x - y).collect(Collectors.toList());
		System.out.println(a);
		for (int i = 0; i < a.size() - 1; i++) {
			if ((a.get(i + 1) - a.get(i)) <= 1) {
				count++;
			} else
				count = 1;
			if (maxSize < count)
				maxSize = count;
		}
		return maxSize;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 2; i > -3; i--)
			System.out.println(i);
		System.out.println(countingValleys(8, "UDDDUDUU"));

		System.out.println(pickingNumbers(Arrays.asList(4, 6, 5, 3, 3, 1)));

		System.out.println(Arrays.toString(twoSum(new int[] { 2, 7, 11, 15 }, 9)));
		
		System.out.println(isPalindrome(121));
	}

	public static int[] twoSum(int[] nums, int target) {

		/*
		 * for(int i=0;i<nums.length-1;i++){ for(int j=i+1;j<nums.length;j++){ if(target
		 * == (nums[i]+nums[j]))return new int[]{i,j}; } } return new int[]{};
		 */
		int[] res = new int[2];
		Map<Integer, Integer> tmpMap = new HashMap<>();
		for (int i = 0; i < nums.length; i++) {
			if (tmpMap.containsKey(target - nums[i])) {
				res[0] = tmpMap.get(target - nums[i]);
				res[1] = i;
				return res;
			}
			tmpMap.put(nums[i], i);
		}
		return res;
	}
	
	public static boolean isPalindrome(int x) {
        int reverseNum=0,tmp=x;
        while(tmp!=0){
            reverseNum=reverseNum*10+(tmp%10);
             tmp=tmp/10;
        }
        System.out.println(reverseNum);
        return (reverseNum == x);
    }

}
