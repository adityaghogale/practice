package com.demo.collection;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a1=new int[5];
		for(int i=0;i<5;i++)
			a1[i]=i*2;
		
		for(int i=0;i<5;i++)
			System.out.println(a1[i]);
		
		System.out.println("---------2D array-------");
		int[][] a2=new int[5][5];
		for(int i=0;i<5;i++)
			for(int j=0;j<5;j++)
			a2[i][j]=i*2;
		
		for(int i=0;i<5;i++)
			for(int j=0;j<5;j++)
			System.out.println(a2[i][j]);
		
		System.out.println("---------3D array-------");
		int[][][] a3=new int[5][5][5];
		for(int i=0;i<5;i++) 
			for(int j=0;j<5;j++)
				for(int k=0;k<5;k++)
					a3[i][j][k]=i*2;
		for(int i=0;i<5;i++) 
			for(int j=0;j<5;j++)
				for(int k=0;k<5;k++)
					System.out.println(a3[i][j][k]);
		
		
	}
		
}
