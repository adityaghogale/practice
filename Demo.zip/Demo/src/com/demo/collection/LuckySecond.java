package com.demo.collection;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LuckySecond {

	public static List<Integer> getOddVal(List<Integer> arr) {
		ArrayList<Integer> temp=new ArrayList<>();
		int size=arr.size();
		for(int i=0;i<size;i++) {
		temp.add(arr.get(i));
			if(arr.get(i)==0) {
				for(int j=0;j<size;j++) {
					if((j+i) >=size)break;
					if(arr.get(j+i)%2 !=0 ) {
						temp.set(i, arr.get(j+i));
					}
				}
			}
		}
		return temp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> lst=Arrays.asList(0,5,0,3);
		List<Integer> lst2=Arrays.asList(0,4,0,3);
		List<Integer> lst3=Arrays.asList(0,1,0);
		System.out.println(getOddVal(lst));
		System.out.println(getOddVal(lst2));
		System.out.println(getOddVal(lst3));
	}

}
