package com.demo.collection;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<Integer,String> mp=new HashMap<>();	
		
		mp.put(1,"Adi");
		mp.put(2,"Adi2");
		mp.put(3,"Adi3");
		mp.put(4,"Adi4");
		mp.put(5,"Adi5");
		
		for(Integer e:mp.keySet()) {
			System.out.println(mp.get(e));
		}
		
		for(Map.Entry<Integer,String> em:mp.entrySet()) {
			System.out.println(em.getKey());
			System.out.println(em.getValue());
		}
		
		mp.forEach((k,v)->System.out.println("Key "+k+" value "+v));
		
	}

}
