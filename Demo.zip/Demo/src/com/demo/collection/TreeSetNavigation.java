package com.demo.collection;

import java.util.TreeSet;

//we perform various NavigableSet operations.

public class TreeSetNavigation {

	public static void main(String[] args) {
		TreeSet<String> ts = new TreeSet<>();
		
		ts.add("Adi");
		ts.add("Luffy");
		ts.add("Zoro");
		ts.add("Sanji");
		ts.add("Jimbei");
		
		System.out.println("Initial set : "+ts);
		System.out.println("Descending order set : "+ts.descendingSet());
		System.out.println("Head Set (Starting till element) : ele->(Luffy)  "+ts.headSet("Luffy", true));
		System.out.println("Tail Set (Starting from element to end): ele->(Luffy) "+ts.tailSet("Luffy"));
		System.out.println("Subset : "+ts.subSet("Jimbei", false, "Sanji", true));
		System.out.println("Subset : "+ts.subSet("Jimbei", "Sanji"));
		
	}
}
