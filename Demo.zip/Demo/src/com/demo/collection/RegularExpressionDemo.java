package com.demo.collection;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionDemo {

	public static void main(String[] args) {
		// Pattern Class\
		
		String p="a*a";
		/*Scanner sc=new Scanner(System.in);
		 * System.out.println("ENter name"); String name=sc.next();
		 */
		String name="aaditya";
		if(Pattern.matches(p, name))
		System.out.println("Name is "+name);
		else
			System.out.println("Invalid name");
		
		
		//Matcher class
		String tmp="Gomu Gomu No Jet Pistol is powerfull Gomu Gomu no mi attack";
		Pattern p1=Pattern.compile("Gomu");
		Matcher matcher=p1.matcher(tmp);
		System.out.println(matcher.matches());
		while(matcher.find())
			System.out.println("Group :"+matcher.group()+" :" +matcher.start()+":"+matcher.end());
	}

}
