package com.demo.collection;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Flaten2DArray {

	public static List<Integer> getFlatenArrIteration(Integer[][] ar) throws Exception {
		if (ar.length == 0)
			throw new Exception("Empty array");
		List<Integer> ls = new ArrayList<>();
		System.out.println(Arrays.deepToString(ar));
		for (Integer[] n : ar) {

			for (Integer n1 : n) {
				ls.add(n1);
			}
		}

		ls.forEach(System.out::print);	
		return ls;
	}

	
	  
	  public static void getFlatenArrStream(Integer[][] ar) {
	  
		  List<Integer> ls=new ArrayList<>();
		  Arrays.stream(ar).flatMap(a->Arrays.stream(a)).forEach(System.out::print);;
	  }
	 
	  public static void getFlaten3DArrStream(int[][][] ar) {
		  
		  int[] ab=Arrays.stream(ar).flatMap(a->Arrays.stream(a)).flatMapToInt(b->Arrays.stream(b)).toArray();
		  System.out.println(Arrays.toString(ab));
	  }
	  
	  private static void flatten(Object object) {
	        if (object.getClass().isArray()) {
	            for (int i = 0; i < Array.getLength(object); i++) {
	                flatten(Array.get(object, i));
	            }
	        } else {
	            System.out.print(object + ",");
	        }
	   }
	  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Employee, Integer> mp = new HashMap<>();
		Integer[][] arr = { { 1, 2 }, { 3, 4, 5, 6 }, { 7, 8, 9 } };
		
		int[][][] vals = {{{1, 2}, {3, 4}}, {{5, 6}, {7, 8 , 9 , 10}}};
		
		System.out.println(arr.length);
		int[][] ar2 = {};
		try {
			Integer[] a = getFlatenArrIteration(arr).toArray(Integer[]::new);
			System.out.println(Arrays.toString(a));
			getFlatenArrStream(arr);
			 getFlaten3DArrStream(vals);
			 flatten(vals);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
