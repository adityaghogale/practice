package com.demo.collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class LinkList1 {

	 public static void main(String args[]){  
		  
		 	List<String> al=new LinkedList<String>();  
		  al.add("Ravi");  
		  al.add("Vijay");  
		  al.add("Ravi");  
		  al.add("Ajay");  
		  
		  Iterator<String> itr=al.iterator();  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
		   
	 		//forward list iterator
			ListIterator<String> lItr=al.listIterator();
			while(lItr.hasNext()) {
				System.out.println("Pos "+lItr.nextIndex()+" value "+lItr.next());
			}
			
			//backward list iterator
			//we have to give size of list while initializing so itr will start from last pos
			ListIterator<String> lrevItr=al.listIterator(al.size());
			while(lrevItr.hasPrevious()) {
				System.out.println("Pos "+lrevItr.previousIndex()+" value "+lrevItr.previous());
			}
	 }
}
