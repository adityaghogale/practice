package com.demo.collection;

public class StaticBlockDemo {
	//Initializer Block 
	{ 	System.out.println("===================================================================================");
		System.out.println("This is common constructor \n This will be executed before para/default constructor every time object is created");
	}
	
	//static block
	static {
		System.out.println("Inside static block.");
		System.out.println("This static block executes when classloader loads the class.\n A static block is invoked before main() method. You can verify the same using.");
	}
	
	//default constructor
	public StaticBlockDemo() {
		System.out.println("This is a default construtor");
	}
	
	public static void main(String[] args) {
		System.out.println("Inside main method");
		StaticBlockDemo st=new StaticBlockDemo();
	}
}
