package com.demo.collection;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

public class LambdaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> cn=(n)->{System.out.println(n);};
		
	
		List<Integer> i=Arrays.asList(1,2,3,4,5,6);
		i.forEach(cn);
		
		//My functional interface
		MyFunctional fun=(st)->{return "?"+st+"?";};
		
		Set<String> st=new HashSet();
		st.add("Adi");
		st.add("Luffy");
		st.add("Zoro");
		Iterator tt=st.iterator();
		while(tt.hasNext()) {
		System.out.println(fun.go((String) tt.next()));
		}
	}

}
