package com.demo.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Optional;

public class CollectionDemo {

	public static void main(String[] args) {

		List<Employee> lst = new ArrayList<>();
		lst.add(new Employee(1, "Adi", "Dev", 35000, 25));
		lst.add(new Employee(2, "Luffy", "Dev", 30000, 26));
		lst.add(new Employee(3, "Zoro", "Fin", 28000, 28));
		lst.add(new Employee(4, "Sanji", "Fin", 31000, 28));
		lst.add(new Employee(5, "Ace", "Log", 20000, 30));
		lst.add(new Employee(6, "Saboo", "Log", 35000, 30));
		lst.add(new Employee(7, "Nami", "Dev", 75000, 28));
		lst.add(new Employee(8, "Robin", "Fin", 35000, 27));
		lst.add(new Employee(9, "Yamato", "Log", 95000, 30));
		lst.add(new Employee(11, "Raju", "Dev", 15000, 24));
		lst.add(new Employee(10, "Dhanish", "Dev", 15000, 22));
		
		System.out.println(lst.size());
	

		Map<String, Double> maxSal = new HashMap<>();
		for (Employee emp : lst) {
			if (maxSal.containsKey(emp.getDept())) {
				if (emp.getSalary() > maxSal.get(emp.getDept())) {
					maxSal.replace(emp.getDept(), emp.getSalary());
				}
			} else {
				maxSal.put(emp.getDept(), emp.getSalary());
			}
		}

		System.out.println("-------List of dev with salary greater than 300000-----------");

		System.out.println("-------USING FILTER-----------");

		lst.stream().filter(a -> "Dev".equalsIgnoreCase(a.getDept())).filter(a -> a.getSalary() >= 30000)
				.filter(a -> a.getAge() > 25).forEach(System.out::println);

		System.out.println("--------USING FOREACH----------");
		lst.forEach(a -> {
			if ("Dev".equalsIgnoreCase(a.getDept()) && a.getSalary() >= 30000 && a.getAge() > 25) {
				System.out.println(a);
			}
		});

		System.out.println("-------------------------------------------------------------------");

		System.out.println("------Salary of dev with 100% hike------------");

		// it will return the return type of field on which map is used.  
		
		lst.stream().filter(a -> a.getDept().equals("Dev")).
		map(a -> a.getSalary() * 2).
		forEach(System.out::println);
		
		lst.stream().filter(a->a.getAge()>25).map(a->a.getAge()+2).mapToDouble(a->a).forEach(a->System.out.println(a));
		System.out.println("------------------done------------");

		
		System.out.println("------Highest Salary of company------------");
		
		Optional<Employee> tmpE=lst.stream().sorted((o1,o2)->o1.getName().compareTo(o2.getName())).findFirst();
		System.out.println(tmpE);
		
		double l = 272.002;
		int n = 264;
		byte num3 = (byte) l;
		byte num4 = (byte) n;
		System.out.println(num3 + " " + num4);
		System.out.println(10 / 1);

		System.out.println();
		List<Employee> llE=new LinkedList<>(lst);
		
		//forward list iterator
		ListIterator<Employee> lItr=llE.listIterator();
		while(lItr.hasNext()) {
			System.out.println("Pos "+lItr.nextIndex()+" value "+lItr.next());
		}
		
		//backward list iterator
		//we have to give size of list while initializing so itr will start from last pos
		ListIterator<Employee> lrevItr=llE.listIterator(llE.size());
		while(lrevItr.hasPrevious()) {
			System.out.println("Pos "+lrevItr.previousIndex()+" value "+lrevItr.previous());
		}
	}

}
