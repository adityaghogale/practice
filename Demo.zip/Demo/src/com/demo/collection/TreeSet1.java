package com.demo.collection;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSet1 {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<>(); 
		
		
		ts.add("Adi");
		ts.add("Luffy");
		ts.add("Zoro");
		ts.add("Sanji");
		ts.add("Jimbei");
		
		//Iterating in ascending order
		System.out.println("Traversing in ascending order");
		Iterator itr=ts.iterator();
		while(itr.hasNext()) {
			System.out.print(itr.next()+" ");
		}
		
		//Iterating in descending order
		System.out.println("\n\nTraversing in descending order");
		Iterator itr2= ts.descendingIterator();
		while(itr2.hasNext()) {
			System.out.print(itr2.next()+" ");
		}
		
		//to remove highest value
		System.out.println("\nPoll first i.e. Lowest value = "+ts.pollFirst());
		//to remove lowest value
		System.out.println("Poll last i.e. Highest value = "+ts.pollLast());
		
		ts.forEach(a->{System.out.println(a+" ");});
		
	}
}
