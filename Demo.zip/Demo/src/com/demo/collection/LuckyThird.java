package com.demo.collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class LuckyThird {

	public static Employee getNthLowestSalary(List<Employee> empList,int n) {
		List<Employee> et;
		Employee e;
		
		et=empList.stream().sorted((emp1, emp2) -> (int)(emp1.getSalary() - emp2.getSalary())).collect(Collectors.toList());
		e=et.get(n-1);
		for(Employee el:et) {
			System.out.println(el);
		}
		return e;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Scanner sc=new Scanner(System.in); int n=sc.nextInt();
		 */
		int n=2;

		List<Employee> lst=new ArrayList<>();
		lst.add(new Employee(1,"Adi","Dev",35000,25));
		lst.add(new Employee(2,"Luffy","Dev",30000,26));
		lst.add(new Employee(3,"Zoro","Fin",28000,28));
		lst.add(new Employee(4,"Sanji","Fin",31000,28));
		lst.add(new Employee(5,"Ace","Log",20000,30));
		lst.add(new Employee(6,"Saboo","Log",35000,30));
		lst.add(new Employee(7,"Nami","Dev",75000,28));
		lst.add(new Employee(8,"Robin","Fin",35000,27));
		lst.add(new Employee(9,"Yamato","Log",95000,30));
		lst.add(new Employee(10,"Raju","Dev",15000,24));
		
		System.out.println(getNthLowestSalary(lst, n));
		
	}

}
