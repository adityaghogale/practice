package com.demo.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ArrayListPract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> ls=new ArrayList<>(Arrays.asList(1,3,5,7,5));
		List<Integer> ls2=new ArrayList<>(Arrays.asList(2,4,6,2,8));
		
		List<Integer> ans=Stream.concat(ls.stream().distinct(),ls2.stream().distinct()).sorted().collect(Collectors.toList());
		
		ans.forEach(System.out::print);
		
	}

}
