package com.demo.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class UniqueArrayElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> arr1 =Arrays.asList(2,9,3,100,0,5,-31,-2);
		List<Integer> arr2=Arrays.asList(10,15,0,4,2,-31);
		/*
		 * arr1.add(2); arr1.add(8); arr1.add(10); arr1.add(3); arr2.add(5);
		 * arr2.add(11); arr2.add(10); arr2.add(4);
		 */
		arr1.sort((x,y)->x-y);
		Integer smallest=arr1.get(0);
		for(Integer i:arr1){
			if(!(arr2.contains(i))) {
				System.out.println("Smallest element from both is "+i);
				break;	
			}
		}
		
		List<Integer> ls=new ArrayList<>();
		ls=Collections.synchronizedList(ls);
		ls.add(1);
		ls.add(2);
		ls.add(3);
		ls.add(4);
		ls.add(5);
		ls.add(1,6);
		ls.remove(1);
		
		}
		
	}


