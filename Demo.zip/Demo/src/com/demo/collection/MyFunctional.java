package com.demo.collection;

@FunctionalInterface
public interface MyFunctional {

	public String go(String s);
}
