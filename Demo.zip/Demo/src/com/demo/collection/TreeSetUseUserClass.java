package com.demo.collection;

import java.time.LocalDate;
import java.util.TreeSet;

/* To add user-defined objects in TreeSet, 
	you need to implement the Comparable interface.
	if we don't implement Comparable we will get ClassCastException
*/
class Jadu implements Comparable<Jadu>{
	private int testId;
	private String subject;
	private LocalDate testDate;
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public LocalDate getTestDate() {
		return testDate;
	}
	public void setTestDate(LocalDate testDate) {
		this.testDate = testDate;
	}
	@Override
	public String toString() {
		return "test [testId=" + testId + ", subject=" + subject + ", testDate=" + testDate + "]";
	}
	public Jadu(int testId, String subject, LocalDate testDate) {
		super();
		this.testId = testId;
		this.subject = subject;
		this.testDate = testDate;
	}
	public Jadu() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int compareTo(Jadu j1) {
		return this.getTestDate().compareTo(j1.getTestDate());
	}
	
}
public class TreeSetUseUserClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<Jadu> ts = new TreeSet<>();
		ts.add(new Jadu(1,"Maths",LocalDate.of(2022, 12, 20)));
		ts.add(new Jadu(2,"Physics",LocalDate.of(2022, 12, 1)));
		ts.add(new Jadu(3,"CS",LocalDate.of(2022, 11, 25)));
		
		System.out.println(ts);
	}

}
