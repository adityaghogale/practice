package com.demo.collection;

import java.util.Stack;

import org.w3c.dom.Node;

public class StackDemo {

	static final public void main(String ars[]) {
		
		try {
			System.out.println("hello");
		}
		catch(Exception e) {
			System.out.println("Byeee");
		}
		finally {
			System.out.println("FInal byee");
		}
		
		String s="() {}";
		Stack<Character> brackets=new Stack<>();
		brackets.removeAllElements();
		char ch;
		for(int i=0;i<s.length();i++) {
			ch=s.charAt(i);
			switch(ch) {
			case '}':if(!(brackets.isEmpty()) && brackets.peek() == '{')brackets.pop();
					else brackets.push(ch);
					break;
					
			case ')':if(!(brackets.isEmpty()) && brackets.peek() == '(')brackets.pop();
					else brackets.push(ch);
					break;
					
			case ']':if(!(brackets.isEmpty()) && brackets.peek() == '[')brackets.pop();
					else brackets.push(ch);
					break;
			default : brackets.push(ch);
			}
			
		}
		System.out.println(brackets);
		if(brackets.isEmpty())System.out.println("a balanced string");
		else System.out.println("not a balanced string");
		
	}
	
	
}
