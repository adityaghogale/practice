package com.demo.collection;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Queue<String> qu=new LinkedList<>();
		qu.add("Aditya");
		qu.add("Luffy");
		qu.add("Zoro");
		qu.add("Sanji");
		qu.add("Ace");
		qu.add("Sabo");
		//return but not remove head of queue
		System.out.println(qu.peek());
		//return and remove head of queue
		System.out.println(qu.poll());
		System.out.println(qu.peek());
		//add element in queue like "add method" but should be use than "add" method
		qu.offer("Jadu");
		
		//A predicate is a function that receives an input and returns a boolean value.
		qu.removeIf((q->{return q.equals(new String("Jadu"));}));
		
		qu.forEach(System.out::print);
		
		
	}

}
