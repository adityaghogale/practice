package com.demo.collection;

import java.util.HashMap;
import java.util.Map;

public class TreeMapDemo {

	public static void main(String[] args) {
		Map<Character,Integer> mp=new HashMap<>();
		
	}

}
